# R13 H2 correction paths

These paths are source readings of `harness.py` and `controller.py` in `MIZAN_A2_R13_MEMORY_REVIEW_H2`. They were not executed. No fixture, mock, decoder probe, target call, or receipt was created for them.

Line numbers are the lines in this candidate. They are not the R13 H1 anchors.

## F001 — argument integrity

`compose_arguments` returns the actual argument tuple. `run_suite` then snapshots that tuple at `1841–1843`, emits `started` at `1851`, and calls `function(*args)` at `1856`. `argument_integrity` at `1789–1805` runs at `1863–1865` for every path that reaches that call and returns control. The three facts stay separate: the call outcome, `harness_match` from `same_exact(value, expected)`, and `argument_integrity`.

The pre-call baseline is `graph_snapshot(args)` after composition. It is not built from `s["expected"]`. The setup-time `case_snapshot` from `finish_spec` at `1070` is compared again and is not replaced. Producer snapshots taken at `1825` are compared again. A shared child or a cycle is a `("ref", index)` node inside `graph_snapshot` at `182–207`. The same structure compares equal. It is not treated as a mutation by itself.

### Unchanged normal return

`stop_reason` is empty and `STOP_REQUESTED` is false, so the rank is not skipped at `1816`. The setup-time case compare at `1822` matches. `compose_arguments` returns. Producer snapshots and, only for `0223`, the secret-row snapshot are taken. The second stop check at `1837` does not fire. `graph_snapshot(args)` succeeds. `started` is emitted. The call returns, so `call_outcome` stays `"return"`. `argument_integrity` finds the argument graph, the case, and each producer return equal to their baselines and returns `"preserved"`. `same_exact(value, s["expected"])` is the match fact. One `completed` event carries both `harness_match` and `argument_integrity`. Because integrity is `"preserved"`, the block at `1906` does not emit an integrity boundary and does not set `stop_reason`. Later ranks remain eligible for selection.

### Mutation of the injected 0253 argument, with an otherwise matching return

`R13-V-0253` is built at `1479–1483`. The written input is `t_base(pattern_match=None)`, stored as a one-tuple on `s["injected"]`, with mode `annotate_injected`. The review's name for that written record is the injected T-UNREAD input. The source constructs it with `t_base`, not with a separate class. The declaration is `D-ABSENT`, so `case_for` returns the shared incomplete case. The pattern token is `key-present:exact-declared-tuple:REP-SECOND.call-1`, so `patterns_for` returns the case's pattern tuple itself. `compose_arguments` at `1751–1753` therefore builds `(injected_tuple, pattern_tuple, case)`.

`e_val` at `1483` builds the expected record from the written fields before any call. `finish_spec` deep-copies that expected value. The expected object is not the injected dictionary.

Suppose the callee returns a value that `same_exact` accepts as that frozen E-VAL record, and also changes the injected dictionary, leaving the case and its pattern tuple unchanged. This is the review's contrast. It is not a claim about pinned R13, and it was not run.

The pre-call snapshot contains the injected dictionary, the pattern tuple, and the case, including the alias from the pattern argument back to the tuple inside the case. After the call, `graph_snapshot(args)` differs in the injected dictionary. `argument_integrity` returns `"mutated"` at `1796–1797`. The empty dependency list adds no producer mismatch. The case compare can still match. That does not cancel the argument mismatch.

The `completed` event keeps `harness_match` true and sets `argument_integrity` to `"mutated"`. `actual` is `public_tree` of the returned value. The expected record is not written over that return. At `1906–1910` the reason is `caller-argument-or-provenance-mutated`, `stop_reason` becomes that reason, and a boundary is emitted. The injected object is not restored. The call is not replayed. Later ranks take the `not_run` path at `1816`. The child returns 2 at `1925–1926`.

The parent sees the boundary and the issue `argument-integrity` from `note_integrity` at `609–614`. `protocol_complete` at `799` is false. `measurement_complete` at `974–978` is false. The parent assessment is `execution incomplete` and the parent status is 2. The attempt is not eligible.

### Observation-only mutation

For an ordinary comparison, the `else` branch of `compose_arguments` at `1775` returns `(case, observation, assertion)`. The observation and the assertion are inside `args`, so they are inside the pre-call snapshot even when they are not the case object and not a producer return. An observation-row change that leaves the return matching and leaves the case snapshot matching still fails `same_exact` of the argument snapshots. The event and the boundary are the same shape as the 0253 contrast: `harness_match` can stay true, `argument_integrity` is `"mutated"`, and later selection stops.

`0191` and `0193` pass a separately selected assertion object in that tuple. A change to that object is an argument-graph change. `0179` and `0180` use mode `utility`, so `args` is `s["args"]` and `case` is `None`. The case compare is skipped at `1798`. The utility operands are still in the argument snapshot. The `0223` secret-row check remains an additional dedicated check. It is not the only observation baseline.

### Mutation followed by an ordinary target exception

The `except Exception` arm at `1857–1859` stores `call_outcome = "exception"` and `error_type = type(exc).__name__`. It does not `continue`. `argument_integrity` still runs. The `else` arm at `1897–1902` emits one `errored` event with that original `error_type` and the integrity value. It does not emit `completed`, and it does not replace `error_type` with a snapshot error. If integrity is `"mutated"`, `1906–1910` emits the mutation boundary and sets `stop_reason` only when it is still empty. Later ranks are not selected. The returned control is the exception. The integrity fact is the separate field and the boundary.

### BaseException path

The `except BaseException` arm at `1860–1862` stores `call_outcome = "base"` and the original class name. `argument_integrity` still runs. One `errored` event carries that `error_type`. At `1903–1905` `stop_reason` is set to `target-base-exception` and that boundary is emitted. If integrity is not `"preserved"`, the assignment at `1908` does not replace `target-base-exception`, and a second boundary carries the integrity reason. Two boundary events are not two terminal call events. There is one `errored` event. The child returns 2. A snapshot failure on this path does not erase the base-exception boundary.

### Shared or cyclic input remaining unchanged

`graph_snapshot` records the first visit of a container and later visits of the same object as `("ref", index)`. A cycle and a child shared by two arguments are that reference structure. `same_exact` compares the resulting snapshot tuples, including those references. An unchanged shared or cyclic input therefore returns `"preserved"`. The structure is not reported as a mutation merely because it is shared or cyclic. This follows from `182–207` and from `argument_integrity`. It was not executed.

### Failure of a required snapshot or check

If `graph_snapshot(args)` raises at `1843`, including `PreparationError("snapshot-size")`, the handler at `1844–1849` sets `stop_reason` to `argument-integrity-not-established`, emits that boundary, and emits `not_run`. `started` is not emitted. `getattr` and the target call are not reached.

If a post-call snapshot or compare raises, `argument_integrity` returns `"not-established"` at `1803–1804`. The terminal event still carries the original return or the original `error_type`, with `argument_integrity` set to `"not-established"`. The boundary reason is `argument-integrity-not-established`. The field is not `"preserved"`.

If the process is killed after the call and before any post-call write, this runner does not invent the integrity field.

A residual reporting limit remains. `argument_integrity` is computed before `public_tree` and the terminal `emit`. If that encoding or emit raises, execution leaves `run_suite` before the integrity boundary at `1910`. The handler at `2013–2021` emits `harness-setup-or-reporting-failure` and the child status is 2. That path does not record preservation as true. The integrity field may be absent from the captured stream. This is not the H1 early-continue bypass. The H1 bypass skipped the check on exceptional returns that had already been caught inside `run_suite`.

`graph_snapshot` stores an unsupported object as type name and identity only. Interior mutation of an unsupported mutable object is outside the check. The prescribed values are dictionaries, tuples, lists, strings, integers, booleans, `None`, and passive `str` subclasses. `PassiveText` is immutable. Replacing one unsupported object with another changes the stored identity and is visible. A mutation that is undone before the call returns is also outside what the before/after snapshots establish.

## F002 — attribution across an incomplete stream

`decode_protocol` starts every ledger ID at `573–580` with disposition `unknown`, start unobserved, and completion unobserved. A vector event is stored only after protocol, prepared, ID, and exact ledger-rank checks at `628–675`. `type(rank) is int` rejects a boolean. The frontier at `584` counts contiguous in-order terminals. `mark_gap` at `590–594` appends `schedule-gap` once. Later events do not clear it and do not advance the frontier while it is set.

`vectors.json` is `[result[xid] for xid in ids]` at `800`. That is ledger order. It is not observed event order.

No path below was parsed or executed.

### Valid complete stream

A prepared event is accepted before any vector event. For each ledger ID in order, a matching `started` sets `pending` when `in_order` is true at `699–701`. The matching `completed` or `errored` for that same ID clears `pending` and increments `frontier` at `733–737`. After 288 such terminals, `frontier` is 288 and `pending` is empty. A `finished` event with `stop_reason` null and totals equal to the seven recomputed keys adds no issue. With no boundaries and no schedule gap, `protocol_complete` is true. If every retained terminal is a matching completion, the parent can reach exit 0 and `eligible for separate reviewer decision`. That eligibility is still not source acceptance. This description is the control flow. It is not a captured stream.

### Rank 266 / rank 267 gap

The ledger order used by `ids` is `0001` through `0265`, then `0283`, then `0266`. After complete in-order pairs through rank 265, `frontier` is 265 and `ids[265]` is `R13-V-0283`. `pending` is empty. The `R13-V-0283` row is still the initial record.

There is no usable event for `R13-V-0283`. Its row is not updated. Start stays `start-unobserved`. Completion stays `completion-unobserved`. Disposition stays `unknown`. The decoder does not infer that it never ran and does not invent a block.

The next captured record is:

```json
{"protocol":"mizan-a2-r13-h1","event":"not_run","id":"R13-V-0266","state":"blocked/not-run","reason":"producer-return-absent","selection_rank":267}
```

The ID is in the ledger. Rank 267 is an `int` and is the ledger rank of `R13-V-0266`. The row has no start and no terminal. `pending` is empty, so `not-run-while-other-pending` is not added. At `754–755` disposition becomes `blocked`, `observation_state` becomes `blocked/not-run`, and the event is stored. `started_observed` and `completed_observed` stay false. The later labels are therefore `start-unobserved` and `completion-unobserved`. No start and no return are fabricated.

`in_order` at `756` compares `R13-V-0266` with `ids[265]`, which is `R13-V-0283`. They differ, so `mark_gap` runs and `frontier` stays 265. The issue `schedule-gap` remains. A later valid event can still be stored, and it does not clear the gap or move the frontier.

`finished`, if present, fails the complete-frontier test at `656–657`, so `incomplete-vector-protocol` is added. `protocol_complete` is false because of the issues and the gap. `started + not_run` is not 288 while `0283` remains unknown. The parent assessment is `execution incomplete`. Exit 0 is not taken. The attempt is not eligible as all-matching evidence.

The retained `0266` event is evidence that a blocked decision was captured. It is not evidence of the runtime state of `0283`.

### Start without a terminal

A valid in-order `started` sets `started_observed` and, while disposition is still `unknown`, sets `observation_state` to `completion-unobserved`. `pending` becomes that ID. No terminal is stored. At `finished`, `pending` is still set, so `incomplete-vector-protocol` is added. Disposition stays `unknown`. Completion stays unobserved. The protocol is incomplete.

### Terminal without a captured start

A `completed` or `errored` for a row with `started_observed` false appends `return-without-start` at `714–715` and still stores the terminal. Disposition becomes `completed` or `errored`. The start label stays `start-unobserved` unless a separate valid `started` event is captured. The terminal is not rewritten into a start.

If that terminal is exactly `ids[frontier]`, `schedule_gap` is false, and `pending` is empty or is that same ID, `frontier` advances at `733–737`. A missing start is then not also a schedule hole. `return-without-start` remains an issue, so `protocol_complete` stays false. A start is not invented from the return.

### Explicit block with producer evidence

When the producer's terminal was the previous in-order frontier step, `pending` is empty and the dependent ID is `ids[frontier]`. The dependent `not_run` with state `blocked/not-run` is stored as disposition `blocked`, with start and completion unobserved. `in_order` is true, so `frontier` advances and `schedule-gap` is not set by that event. An explicit in-order block is a retained decision, not a gap. If the rest of the schedule is complete and otherwise clean, `protocol_complete` can be true while `not_run` is nonzero. The parent then uses exit 1 and `completed with unexpected comparator failures`. It does not use exit 0.

### Explicit block without producer evidence

This is the rank 266 / 267 reading above. The block is stored. The missing producer stays unknown. The gap stays. The attempt stays incomplete. A missing producer event, with no captured dependent block, does not create a block for the dependent. The dependent remains the initial `unknown` row.

### Unknown ID or invalid rank

An ID absent from the ledger appends `unknown-vector-id` and, until 32 such lines, the byte offset. The frontier is not moved. The line is not written onto another vector. A rank that is missing, not an exact `int`, or not the ledger rank for that ID appends `selection-rank` and the same kind of offset, then continues before the row is updated. A boolean rank fails `type(rank) is int`. The corrupt line does not by itself freeze the frontier, so a later in-order attributable event can still be stored. The issue remains, so the protocol stays incomplete either way.

### Duplicate or contradictory events

A second `started` appends `duplicate-start`, records a conflict, marks the gap, and continues at `691–695` before changing the first start. A second `completed` or `errored` does the same with `contradictory-terminal` at `709–713`. A `not_run` after a start or a terminal is also a conflict at `747–751` and does not replace the stored disposition. A `started` after a terminal is a conflict at `686–690` and does not set `started_observed`. The first fact remains. Conflicts keep `kind`, `selection_rank`, and `byte_offset`, at most 8 records per vector. `conflict_overflow` counts the rest. The `conflicts` total adds those records and the overflow. It does not add another call to `started`, `completed`, or `not_run`.

Reordering an attributable event so it is not `ids[frontier]` stores the event and calls `mark_gap`. The stored fact does not heal the stream. `protocol_complete`, measurement completeness, reviewer eligibility, and exit 0 stay false while any required protocol condition is missing or contradictory.
