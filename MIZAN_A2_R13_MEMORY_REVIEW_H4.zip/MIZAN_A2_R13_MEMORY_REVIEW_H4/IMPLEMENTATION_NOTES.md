# R13 memory-review H4 implementation notes

Candidate: `MIZAN_A2_R13_MEMORY_REVIEW_H4`

This package was written for static review. It keeps the H3 decoder and adds one exact-string check before `input_kind` set membership, the remaining residual of R13-H2-F001. Nothing in it was imported, compiled, or executed during authoring. The inactive template is not an execution approval. A complete matching measurement, if one is later authorized and captured, would only be eligible for a separate reviewer decision. These notes do not close R13-H2-F001 and do not accept the candidate.

`H2_TO_R13_H1.diff`, `H1_TO_H2.diff`, `H2_TO_H3.diff`, `H2_CORRECTION_PATHS.md`, `H2_FINDING_DISPOSITION.json`, `H3_CORRECTION_PATHS.md`, and `H3_FINDING_DISPOSITION.json` are byte-identical historical records. They are not new H4 checks. Two sentences in the H3 evidence contract and H3 path document are qualified in `H4_CORRECTION_PATHS.md`. `H3_TO_H4.diff` compares this candidate with the preserved R13 H3 tree.

## Selection

The accepted `A2_R13_VALIDATION_LEDGER.csv` is stored byte-for-byte. Its historical `implementation_authorized`, `fixture_constructed`, and `implementation_ready` cells were not edited. Those cells do not omit a vector and do not record that a fixture was constructed in this round.

`call_ledger.json` is the rank-ordered projection the future child and parent both read. Each object copies every CSV cell, then adds `derived`:

| Derived field | Rule |
| --- | --- |
| `dependencies` | `dependency_ids` split on `;`, empty parts dropped |
| `recipe` | the text after ` recipe ` in `input_ref`, or `""` |
| `source_version` | H2 ledger literal for 0001–0239; JSON null for 0240–0288 |

`source_version` is an engineering completion. It is not a CSV column and it is not a second schedule. The 239 inherited literals were read from the historical H2 harness text and match that ledger: 141 `A1`, 92 `BASE`, and 6 nulls (`0167`, `0168`, `0173`, `0174`, `0179`, `0180`).

Future order is `selection_rank`: `0001`…`0265`, then `0283` once at rank 266, then `0266` at rank 267, then `0267`…`0282`, then `0284`…`0288`. Numeric identifier order is not the call order.

## Where the H2 text went

Copies live inside this package. The future process does not import or execute the historical H2 modules.

Retained as adapted text:

- The type-aware `same_exact` oracle, graph snapshots, secret collection, and `public_tree`.
- The written record helpers through `normal_dispatch_expected`.
- The 0001–0223 recipe chain, including the H2 completions for `0121` and `0198`–`0202`.
- One POSIX parent, the retained direct child, retained-byte bootstrap, empty child environment, and `supervise` body.
- Separate clocks: workload 120 seconds from T0, grace 5 seconds from the stop decision, reap observation 2 seconds from the forceful request, EOF drain 2 seconds from observed exit when needed.
- Raw retention 1048576 bytes per stream and a 4096-byte read quantum per ready stream per cycle.
- `guard_counts` null and `prohibited_operation_coverage` `not-instrumented`.

Replaced for this package:

- Wire protocol `mizan-a2-r10-h1` becomes `mizan-a2-r13-h1`. Historical H2 provenance records are not rewritten. The old string remains only in the harness docstring as the value being replaced.
- Planned calls 239 and 107 groups become 288 calls and 119 groups, with the V4 entrypoint counts.
- Block B expectations are V4 section 6. The H2 characterization branch, including `expected_from_R10_static_reading` and `contract_acceptance_status`, is not the R13 expectation. The parent treats those keys as a protocol issue if a future event carries them.
- The success label is not H2's "completed with known open characterization issue".

Added:

- `passive_text`, declaration materialization, Block C builders, and the rank projection check.
- Separate start-observation and completion-observation fields, and a disposition that stays `unknown` when the required event is absent.

`read_fd` still reads a regular file in chunks of at most 65536 bytes. That chunk is not a protocol-line stop. The 65536-byte protocol-line stopping rule stays removed. A partial or malformed protocol line still fails evidence interpretation.

## Declarations and patterns

`declaration_ref` selects the object. `case_id` records catalog ancestry and is not used alone.

| Declaration | Object |
| --- | --- |
| `catalog` | a fresh deepcopy, except `0163` and `0164`, which share one inherited `B12` case object |
| `INTACT-REP`, `INTACT-NONEW`, `INTACT-RECENT`, `INTACT-NEG` | a fresh deepcopy of the named catalog case |
| `D-ABSENT`, `D-NONE`, `D-INT`, `D-EMPTY`, `D-SUB`, and the three `CHK-D-*-table-deleted-copy` names | one shared object per declaration name |

`0271` and `0272` use `INTACT-REP`. `0226`, `0230`, `0234`, and `0238` use the same shared incomplete copies as `0224`, `0228`, `0232`, and `0236`. Deleting or replacing `table` does not edit `base_regression_patterns`.

Annotation passes the case's declared tuple when the key is present, including the empty tuple, and literal `()` when the key is absent. `patterns_for` refuses a present key on a key-absent token, a missing key on a key-present token, and a non-empty tuple on an empty-tuple token. It does not add a key, borrow another case's tuple, omit the argument, or pass `None`.

Injected records for paired vectors are separate dictionaries built from the same written template. They are not one shared mutable object. `E-COPY` deep-copies that written template and sets `pattern_match` to `not_applicable` when `source_version` is `A1`. It does not copy a future actual return.

`0240` produces the forbidden outer index. `0241` annotates that actual return. `0242` classifies an independent injected record against `T-CLASS-ENV` and has an empty dependency list. `0243` dispatches a fresh outer-index observation. Its expected tuple is six `T-OUTER` assertion records plus the case-level `E-REG`, sorted by the seven `REP_ASSERTIONS` identifiers. `0239` stays the five companion passes plus the shared validation record plus the shared `E-REG`, in that same identifier order.

Block B return values follow V4 section 6: producer and classifier records use `observation_unavailable`, location `table`, detail `field-absent:table`. `0236` and its consumers keep `call_index` as the exact string `unavailable`. `0224`, `0228`, and `0232` keep integer `1`. Historical plan section 9's `malformed_input` / `table-required` producer wording, and section 9.2's `call-index-type` wording for X-0238, are not R13 expectations. Input shape still follows the retained plan: the incomplete copy is `case_entry`, the dispatcher builds a fresh observation from the intact catalog case, and `0238` requires `call_1` with no outer `call_index` and no `call_2`. CHK-D-01, CHK-D-02, and CHK-D-03 each have one catalog assertion, so the dispatcher observation for `0227`, `0231`, and `0235` is that one assertion.

## Subclass constructors

`passive_text` defines `class PassiveText(str)` inside the function, with no overridden method, and returns `PassiveText(text)`. Writing the module does not execute that class statement. A future approved setup would call it for inherited `0160` (observation table name `background_tasks`) and for `D-SUB`, `0257`, `0258`, `0285`, and `0286` on the slots named in V4. The CSV still says `fixture_constructed=false` and `implementation_ready=false` for those seven identifiers. This round did not construct a class or an instance.

No public call was added for `index_rows_by_identifier`. No private validator is called.

## Oracle and dependencies

Expectations are built from the written templates and catalog literals inside `build_suite`, which the child reaches only after the projection check and only in a future authorized run. They are not taken from an R13 return or from H2 actuals. `same_exact` requires equal types, so a bool is not an int and a tuple is not a list. It does not sort the actual return, drop duplicates, or ignore a diagnostic field. Dictionary key order is not a contract. Sequence order and key presence are.

The raw return is stored even when it mismatches. Annotation and classification receive that stored object when their provenance says so. A completed one-element tuple or list of a dictionary remains usable when the dictionary status is `failed`. Any other missing or unusable prerequisite emits one `blocked/not-run` event at that rank and does not retry.

`0219` depends on `0218` as well as `0206` and `0208`–`0216`. `0220` depends on `0206` and `0208`–`0216` and does not depend on `0218`. Its first control is the injected eight-field dictionary, followed by element 0 of those producer returns. The outcomes argument remains the raw `0206` tuple.

## Projection checks

`controller.projection_acceptable` and `harness.correspondence` both compare the projection with the CSV. They are duplicated on purpose. The parent does not import the harness. The harness check also compares `derived.source_version` with `INHERITED_SOURCE_VERSION` before either R13 module is loaded. The parent check does not repeat that version table. A projection whose version field disagrees fails in the child before `load_whole_module`, as a setup failure rather than a skipped vector.

Both checks require the thirteen entrypoint counts, 119 groups, unique ranks 1–288, and the rank schedule. A dependency must already appear earlier in that schedule.

## Assessment mapping

The child exit and the parent exit are different observations. The parent does not treat a printed total as proof of exit.

| Condition | Child exit | Parent assessment | Parent exit |
| --- | --- | --- | --- |
| Boundary, protocol, identity, or schedule capture is incomplete, including a child stop reason or a child exit of 2 | 2 when the child itself stopped | `execution incomplete` | 2 |
| The measurement is complete and any comparator mismatch, target exception, or explicit `not_run` / `blocked/not-run` is present | 1 | `completed with unexpected comparator failures` | 1 |
| The measurement is complete and all 288 calls completed and matched | 0 | `eligible for separate reviewer decision` | 0 |

`unexpected_by_block` counts completed events whose `harness_match` is false, split by Blocks A, B, and C. A matching negative target status is `harness_match` true and is not added to that count. Explicit blocks and target exceptions force the nonzero result through the totals. They are not rewritten into Block B skips or xfail.

`measurement_complete` requires a complete boundary, `protocol_complete`, unchanged post-exit identities, `started + not_run == 288`, and a child exit equal to 0 or 1 as required by those totals. `protocol_complete` is false when `issues` is nonempty, a boundary was captured, `schedule_gap` is true, `finished` is absent, or `finished.stop_reason` is not null.

Missing events stay `unknown`. They are not inferred `not-run` or `blocked`. An attributable explicit block is stored by its vector ID and validated ledger rank even when an earlier event is missing. That retention sets disposition `blocked` or `not-run` and leaves start and completion unobserved, because no `started`, `completed`, or `errored` event was captured for that vector. The missing predecessor stays a sticky `schedule-gap`. Retaining the block does not make the protocol complete, the measurement complete, or the attempt eligible for all-matching acceptance.

The H1 note that an explicit block remained visible when the producer event was not captured described the intended contract. The H1 next-ID gate did not implement it. H2 separates attribution from in-order validation. See `H2_CORRECTION_PATHS.md`. The rank-266/267 reading in that file is source reading only. No decoder probe was run.

Exit 0 sets `eligible_for_reviewer_decision` true. It leaves `reviewer_acceptance`, `case_source_accepted`, `a2_c06_closed_by_reviewer`, and `application_or_database_acceptance` false. A nonzero status returns. It does not launch another child or edit the source.

## Identity binding

Pinned byte sizes and SHA-256 values name the historical plan V3, the R13 catalog, the R13 comparisons module, the R13 map, addendum V4, and the accepted CSV. The parent measures those paths from a future authorization file and passes the already measured harness descriptor to the child. The child loads `mizan_a2_r13_catalog` and `mizan_a2_r13_comparisons` from those verified bytes. The map, plan, addendum, and ledger are hash-checked and not executed.

The future child environment is empty. The parent process environment is the launch environment and is not copied into the child. No interpreter was selected or probed in this round. `interpreter_path`, `package_directory`, `evidence_directory`, `approval_reference`, and `attempt_id` stay null in the template.

## Observation limits

These limits are part of the written contract. They are not claims that a guard or a branch was observed.

- No file, network, or process guard is installed. `guard_counts` is null. Coverage of prohibited operations is `not-instrumented`.
- OS isolation, descendant cleanup, writer absence, and inherited OP1 containment are not claimed. Attempt 01's consent does not transfer.
- `R13-SR-09` stays qualified public first results. The internal version-before-disposition branch is not a public call.
- `R13-SR-16` stays qualified unbound public routes. `0284` does not claim the unbound envelope-version branch.
- `public_tree` encodes an exact `str`. A passive `str` subclass is an unsupported evidence value. The match decision still uses `same_exact` on the original objects, before that encoding.
- A captured `started` event is the child's statement that it reached the call site. It is not the parent's proof that the target function body ran.
- Source after-images are recorded only when exit was observed. Otherwise the after-image is null.

## Argument integrity

`graph_snapshot` is unchanged. It is an in-memory graph: containers are nodes keyed by object identity, aliases and cycles are references to those nodes, and an unsupported object is stored only as `("unsupported", type name, id)`. `argument_integrity` compares three baselines and returns `preserved`, `mutated`, or `not-established`. A snapshot or comparison exception is `not-established`. Snapshots are not logged.

The baselines are:

- The setup-time `case_snapshot` taken in `finish_spec`, before any target call. The per-call snapshot does not replace it. Shared-case drift is still refused before `compose_arguments`.
- Producer-return snapshots taken after composition and before the call. A producer object that is also an argument is checked in both places. That is one call, not a replay.
- The assembled `args` tuple, snapshotted after `compose_arguments`, including `control_outcomes` insertion, and before `getattr` and the call. The original argument objects are what the target receives. The baseline is not rebuilt from the expected return.

After the call returns control, the same check runs for a normal return, an `Exception`, and the existing `BaseException` path. There is no `continue` between the call and that check. One terminal event is emitted: `completed` or `errored`. `harness_match` remains the expectation comparison. `argument_integrity` is a separate field. A later boundary names `caller-argument-or-provenance-mutated` or `argument-integrity-not-established`. A mutation or an unestablished check sets `stop_reason` when it is still empty, so later ranks are `not_run` and the child returns 2. The original `error_type` is kept. A `BaseException` sets `stop_reason` to `target-base-exception` first, and a later integrity reason does not replace it. Both boundary events can be present. They are not two terminal call events.

If the pre-call snapshot cannot be established, the target is not called. The rank is `not_run` with reason `argument-integrity-not-established`. If the process is killed before any post-call observation, the runner does not fabricate the check.

The dedicated `0223` secret check remains. When it completes, its two booleans still combine into `harness_match`. When it raises, those booleans are omitted, so the failure is not reported as a comparator mismatch. Integrity becomes `not-established` only when it was `preserved`. A mutation stays `mutated`.

What the check establishes is equality of the bounded snapshot before and after the call. It does not prove that no transient change occurred during the call. Reordering a caller dictionary's keys changes the snapshot, because the snapshot keeps iteration order. The return oracle still ignores dictionary key order. An unsupported object's identity is part of the snapshot. Interior mutation of an unsupported mutable object is not. The prescribed inputs are dictionaries, tuples, lists, strings, integers, booleans, `None`, and passive `str` subclasses. `PassiveText` is immutable. A change from one unsupported object to another is a different identity and is visible.

If `public_tree` or the terminal `emit` raises after `argument_integrity` has already returned, the integrity boundary inside `run_suite` may not be reached. The handler in `main` emits `harness-setup-or-reporting-failure` and the child status is 2. That path does not emit preservation as true. The integrity field can be absent from the stream in that reporting failure. This is a residual limitation of the reporting path, not the H1 early-continue bypass.

Mutated objects are not restored. Calls are not replayed. No target call was added.

## Wire-shape validation

`decode_protocol` checks each finite event before dictionary membership, nested `.get` on an untyped value, or observation credit. The schema is the table in `EVIDENCE_CONTRACT.md`. A list, dictionary, null, number, or absent vector ID is rejected as `vector-id-absent` or `vector-id-type` and is not passed to `in`. A boolean rank is not an integer rank. No `str()` coercion is applied.

`prepared` becomes the trusted binding only when the whole record validates, including every expectation-ledger entry. A malformed entry fails the binding. It is not filtered out. A later prepared record does not replace a trusted binding. If the first prepared record is malformed, it is not stored. A later record that fully validates may become the binding for events after it. Events before that binding stay unattributed. The original defect remains, so the attempt stays incomplete.

A completed record without the `actual` key is `completed-actual-absent`. It is not stored as a return, does not advance the frontier, and does not clear an earlier start. Present `actual` values of null, false, zero, or an empty collection stay present. They are not replaced with an expected result. `harness_match` remains a separate Boolean.

An errored record without a non-empty string `error_type` is `errored-type-absent`. No exception payload is invented. A global `boundary` does not need a vector ID. Known rejected shapes return from the decoder with issues and locators, so `main` can still write the five evidence files. There is no handler that turns a decode failure into an empty successful protocol. An unforeseen decoder fault still uses the existing top-level handler and does not fabricate a receipt.

`input_kind` is checked with `type(...) is str` before membership in the five-string set. A list or dictionary does not reach that membership. The issue remains `input-kind-binding`. A missing `input_kind` key still fails earlier as `completed-field`. The rejected completion is not stored, so an earlier start remains. `started + not_run` can still equal 288 when every start was accepted. The short completion count and the sticky issue keep the attempt ineligible. An absent `argument_provenance` or `consumed_producer_ids` key is also `completed-field`. A present invalid value can reach `provenance-binding` or `consumed-producer-binding` after the earlier checks pass.

## Protocol attribution

`decode_protocol` attributes a vector event only after the shape checks, when `prepared` has been accepted, the ID is an exact string in the ledger, and `selection_rank` is an exact `int` equal to that ID's ledger rank. A boolean is not an int. The numeric suffix is not the rank.

In-order progress is a frontier of contiguous terminals. `schedule-gap` is appended once and is not cleared by a later event. The frontier does not advance across a gap. An attributable event after the gap is still stored.

A captured `not_run` with state `blocked/not-run` or `not-run` is stored when that vector has no start and no terminal yet. Disposition becomes `blocked` or `not-run`. Start and completion stay unobserved. A missing event is not turned into a block, a start, or a return.

A terminal without a captured start records `return-without-start` and does not set `started_observed`. When that terminal is exactly the next frontier ID, the frontier still advances, so a missing start is not also labeled a schedule hole. The issue remains, so the protocol stays incomplete.

The first terminal or start is kept. A duplicate start, a second terminal, a `not_run` after a start or terminal, or a start after a terminal is `contradictory-terminal` or `duplicate-start`, plus one conflict record. Conflicts are capped at 8 records per vector. Further conflicts increment `conflict_overflow`. They do not replace the stored event and are not counted as extra calls.

An unknown ID, a rank that is not the ledger rank, a vector event before `prepared`, or an unknown event kind is an issue and, up to 32 times, a byte offset in `unattributed_byte_offsets`. Those lines do not freeze the frontier by themselves. They do keep `protocol_complete` false. They are not assigned to another vector.

`observed_totals` is recomputed from the retained rows. `unknown` and `conflicts` are parent-only keys. The comparison with `finished.totals` uses the child's seven keys. A disagreement stays `totals-disagree`. The child's totals are not copied over the independent counts.

`vectors.json` follows ledger rank order. That order is not a claim about observed event order. `protocol_complete`, measurement completeness, reviewer eligibility, and exit 0 stay false while a required protocol condition is missing or contradictory.

The wire protocol remains `mizan-a2-r13-h1`. The package name on the receipt is `MIZAN_A2_R13_MEMORY_REVIEW_H4`. `PACKAGE_LABEL` in the harness names that package. The harness runner functions are unchanged from H3 and from H2. Historical provenance strings were not blanket-replaced. The H4 label changes are the harness docstring and `PACKAGE_LABEL`, and the controller docstring, argument-parser description, and receipt package string.

## What this round did not resolve by running

No target, constructor, oracle, loader, decoder, or controller was run, including `--help` and syntax checks. The future `class-env-shape`, catalog-count, and subclass-required checks are therefore unexecuted. No specification field was left without a written builder. No fallback expectation was added. `H2_CORRECTION_PATHS.md` and `H3_CORRECTION_PATHS.md` remain historical source readings. `H4_CORRECTION_PATHS.md` is the H4 source reading. None of those documents was executed.
