"""MIZAN A2/R13 memory-review H4. Source written for static review.
The runner logic is the H2 argument-integrity runner, unchanged.
It is not an acceptance of the candidate and was not executed in the
authoring round. A future launch needs a separate implementation
acceptance and a separate execution approval. The inactive template is
not that approval.

Package identity is MIZAN_A2_R13_MEMORY_REVIEW_H4. The wire protocol
remains mizan-a2-r13-h1. That wire value replaced the historical R10 H2
wire value mizan-a2-r10-h1. Historical provenance records are not rewritten.
Expectations are the accepted V4 templates and catalog literals. They
are not R13 returns and they are not historical actuals.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import io
import json
import os
import signal
import stat
import sys
import types

PACKAGE_LABEL = "MIZAN_A2_R13_MEMORY_REVIEW_H4"
PROTOCOL = "mizan-a2-r13-h1"
PLANNED = 288
CHECK_GROUPS = 119
PINNED = {
    "plan": (78879, "dd241adb46d90eb0811c0d1dcc5bbc72f3067ef8ecd5baa30829904ef7399d19"),
    "catalog": (121298, "fe724e8001303617e08759abcafdc422626b39d8aed2a2564a0f39bec3ce94db"),
    "comparisons": (177397, "3d06fa6ad8605ba74a1395fa265af3ede14fe268f7c2bf061d25e21b0c35de65"),
    "map": (4033, "6b6b5f2c736543580d589ee670dd9b25e8452feebea4774d42d059cba75f72ab"),
    "addendum": (69181, "45d76de1b5722c67c2c37140d098d2ebccaa64d0da2da42049b2ea9e7107f8a5"),
    "ledger": (144197, "1eb5fc79bba34792cfe54da54e00028c520a7f92ff76861af1018d289c81ab81"),
}
PUBLIC_NAMES = (
    "same_typed_value", "missing_observation_fields", "bindings_uniform",
    "index_rows_by_identifier", "compare_protected_rows", "compare_scoped_columns",
    "compare_insert_shape", "compare_rep_second", "compare_exact_field",
    "compare_schema_column", "classify_commit_record",
    "separate_base_regression_metadata", "classify_case_regression", "compare_supplied_case",
)
CALLED_NAMES = (
    "compare_protected_rows", "separate_base_regression_metadata", "compare_rep_second",
    "compare_scoped_columns", "classify_case_regression", "compare_supplied_case",
    "compare_exact_field", "compare_insert_shape", "bindings_uniform",
    "classify_commit_record", "compare_schema_column", "same_typed_value",
    "missing_observation_fields",
)
EXPECTED_ENTRY_COUNTS = {
    "compare_protected_rows": 56, "separate_base_regression_metadata": 59,
    "compare_rep_second": 39, "compare_scoped_columns": 36,
    "classify_case_regression": 36, "compare_supplied_case": 16,
    "compare_exact_field": 11, "compare_insert_shape": 10,
    "bindings_uniform": 10, "classify_commit_record": 5,
    "compare_schema_column": 4, "same_typed_value": 4,
    "missing_observation_fields": 2,
}
SQL_NULL = ("sql-null",)
SECRET_FIELDS = ("password_hash", "reset_token")
STOP_REQUESTED = False
CSV_FIELDS = (
    "vector_id", "block", "check_group", "historical_id", "entrypoint",
    "argument_order", "case_id", "declaration_ref", "assertion_id", "input_ref",
    "argument_provenance", "dependency_ids", "expectation_ref", "pattern_argument",
    "selection_rank", "category", "crosswalk_role", "review_sr_id",
    "v1_disposition", "v2_disposition", "specification_ready",
    "implementation_authorized", "fixture_constructed", "implementation_ready", "notes",
)
REP_ASSERTIONS = (
    "ASSERT-REP-CALL1-EXPLICIT-NULL",
    "ASSERT-REP-CALL1-LEGACY-50000",
    "ASSERT-REP-CALL1-OLD-DONE-PRESENT",
    "ASSERT-REP-CALL1-OLD-ERROR-PRESENT",
    "ASSERT-REP-CALL1-OLD-PENDING-PRESENT",
    "ASSERT-REP-CALL1-OLD-RUNNING-PRESENT",
    "CASE-REGRESSION",
)


class PreparationError(Exception):
    """Deterministic input construction cannot continue; no replacement oracle."""


class Blocked(Exception):
    """A required actual return or usable control dictionary is unavailable."""


def passive_text(text):
    """Future constructor for one passive str instance.

    The class statement is inside this function, so writing this module does
    not execute it. A later approved setup calls it. Direct base is str.
    No method is overridden. Authoring does not call this function.
    """
    if type(text) is not str:
        raise PreparationError("passive-text")

    class PassiveText(str):
        """No overridden behavior."""

    return PassiveText(text)

def read_regular(path, limit):
    """Descriptor-relative traversal: reject symlinks in EVERY path component.

    Returns exact bytes; no resolve(), no SOURCE_BINDING traversal, no imports.
    Does not claim operating-system isolation or immutable filesystem storage.
    """
    if type(path) is not str or not path.startswith("/"):
        raise PreparationError("absolute-path-required")
    parts = path.split("/")[1:]
    if not parts or any(p in ("", ".", "..") for p in parts):
        raise PreparationError("noncanonical-path")
    directory = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    fd = None
    try:
        for name in parts[:-1]:
            new = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            os.close(directory)
            directory = new
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise PreparationError("regular-file-required")
        data = bytearray()
        while len(data) <= limit:
            chunk = os.read(fd, min(65536, limit + 1 - len(data)))
            if not chunk:
                break
            data.extend(chunk)
        if len(data) > limit:
            raise PreparationError("file-size-limit")
        return bytes(data)
    finally:
        if fd is not None:
            os.close(fd)
        os.close(directory)


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def same_exact(actual, expected, depth=0, active=None):
    """Independent oracle: exact types/keys, ordered sequences, no R10 helpers.

    It never calls equality or repr on an unsupported object. Dict key order is
    not a contract; sequence order, key presence and record multiplicity are.
    Unexpected cycles are a mismatch, not a recursion exception or an identity pass.
    """
    if depth > 64 or type(actual) is not type(expected):
        return False
    typ = type(expected)
    if typ is type(None):
        return True
    if typ in (str, int, float, bool, bytes):
        return actual == expected
    if typ not in (dict, tuple, list):
        return False
    if active is None:
        active = set()
    pair = (id(actual), id(expected))
    if pair in active or len(actual) != len(expected):
        return False
    active.add(pair)
    try:
        if typ is dict:
            if any(type(k) is not str for k in actual) or any(type(k) is not str for k in expected):
                return False
            if sorted(actual) != sorted(expected):
                return False
            return all(same_exact(actual[k], expected[k], depth + 1, active) for k in expected)
        return all(same_exact(a, e, depth + 1, active) for a, e in zip(actual, expected))
    finally:
        active.remove(pair)


def graph_snapshot(value):
    """In-memory nonmutation snapshot, including aliasing; never logged unredacted."""
    nodes = []
    seen = {}
    def visit(item, depth):
        if depth > 64 or len(nodes) > 10000:
            raise PreparationError("snapshot-size")
        typ = type(item)
        if typ in (str, int, float, bool, bytes, type(None)):
            return (typ.__name__, item)
        if typ not in (dict, tuple, list):
            return ("unsupported", typ.__name__, id(item))
        oid = id(item)
        if oid in seen:
            return ("ref", seen[oid])
        index = len(nodes)
        seen[oid] = index
        nodes.append(None)
        if typ is dict:
            content = tuple((visit(k, depth + 1), visit(v, depth + 1)) for k, v in item.items())
        else:
            content = tuple(visit(v, depth + 1) for v in item)
        nodes[index] = (typ.__name__, content)
        return ("ref", index)
    root = visit(value, 0)
    return (root, tuple(nodes))


def collect_secrets(value):
    found = {"synth-insert-password-hash": "password_hash"}
    seen = set()
    def walk(item):
        if type(item) not in (dict, list, tuple) or id(item) in seen:
            return
        seen.add(id(item))
        if type(item) is dict:
            for key, child in item.items():
                if key in SECRET_FIELDS and type(child) is str and child:
                    found[child] = key
                walk(child)
        else:
            for child in item:
                walk(child)
    walk(value)
    return found


def contains_secret(value, secrets):
    seen = set()
    def walk(item, depth):
        if depth > 64:
            return True  # Cannot establish secret-free output within our bound.
        if type(item) is str:
            return any(s and s in item for s in secrets)
        if type(item) is bytes:
            return any(s.encode("utf-8") in item for s in secrets if s)
        if type(item) in (tuple, list, dict):
            if id(item) in seen:
                return False
            seen.add(id(item))
            parts = tuple(item.keys()) + tuple(item.values()) if type(item) is dict else item
            return any(walk(child, depth + 1) for child in parts)
        return False
    return walk(value, 0)


def public_tree(value, secrets):
    """Type-preserving, bounded evidence encoding; NOT an equality oracle."""
    active = set()
    budget = [12000]
    def text(s):
        for secret, field in secrets.items():
            s = s.replace(secret, "<redacted:" + field + ">")
        return s
    def walk(item, depth, field=""):
        budget[0] -= 1
        if budget[0] < 0 or depth > 64:
            return {"$diagnostic": "evidence-value-limit"}
        typ = type(item)
        if field in SECRET_FIELDS:
            return "<redacted:" + field + ">"
        if typ is str:
            return text(item)
        if typ is bytes:
            if any(s.encode("utf-8") in item for s in secrets):
                return "<redacted:secret-bytes>"
            return {"$bytes_hex": item.hex()}
        if typ in (type(None), bool, int):
            return item
        if typ is float:
            return {"$float": item.hex()}
        if typ not in (tuple, list, dict):
            return "<unsupported:" + text(typ.__name__) + ">"
        if id(item) in active:
            return {"$diagnostic": "cycle"}
        active.add(id(item))
        try:
            if typ is dict:
                # Tagged pairs preserve even unexpected non-string key evidence safely.
                return {"$dict": [[walk(k, depth + 1), walk(v, depth + 1, k if type(k) is str else "")] for k, v in item.items()]}
            return {"$" + typ.__name__: [walk(v, depth + 1) for v in item]}
        finally:
            active.remove(id(item))
    return walk(value, 0)


def record(case, assertion_id, version, call_index, table, status, location, detail, **overrides):
    """Written T-REC schema. This function does not read a target return."""
    value = {
        "assertion_id": assertion_id, "status": status,
        "case_id": case["case_id"] if case is not None else "",
        "fixture_id": case["fixture_id"] if case is not None else "",
        "source_version": version, "call_index": call_index, "table": table,
        "location": location, "detail": detail, "discrepancy_kind": "",
        "field": "", "row_locator": "", "pattern_match": "not_applicable",
        "checked_classification": "", "case_regression": "not_applicable",
        "result_role": "assertion", "value_role": "",
    }
    value.update(overrides)
    return value


def expected_sort(records):
    """Frozen public order, implemented here, never via the target's sorter."""
    names = ("assertion_id", "call_index", "table", "location", "detail", "status")
    return tuple(sorted(records, key=lambda r: tuple(str(r[n]) for n in names)))


def regression(case, version, status="passed", location="case-regression", detail="no-pattern-declared", regression_state="not_applicable"):
    return (record(case, "CASE-REGRESSION", version, "case", "", status, location, detail,
                   result_role="case-regression", case_regression=regression_state),)


def observation_index(assertion):
    return "1|2" if assertion.get("rep_kind") == "no-new-change" else assertion["call_index"]


def diagnostic(case, assertion, version, status, location, detail, **changes):
    item = record(case, assertion["assertion_id"], version, observation_index(assertion),
                  assertion.get("table", ""), status, location, detail)
    item.update(changes)
    return (item,)


def validation(injected, status, location, detail):
    c = {"case_id": injected.get("case_id", ""), "fixture_id": injected.get("fixture_id", "")}
    return (record(c, injected.get("assertion_id", ""), injected.get("source_version", ""),
                   injected.get("call_index", "unavailable"), injected.get("table", ""),
                   status, location, detail,
                   pattern_match="malformed_input" if status == "malformed_input" else "unavailable",
                   case_regression="unavailable"),)


def identity_expected(case, assertion, version):
    kind = assertion["comparison_kind"]
    base = dict(case=case, assertion_id=assertion["assertion_id"], version=version,
                call_index=observation_index(assertion), table=assertion.get("table", ""), status="passed")
    if kind == "rep-second" and assertion["rep_kind"] == "no-new-change":
        return (record(**base, location="call:1|call:2 table:" + assertion["table"], detail="no-new-change"),)
    if kind in ("protected-rows", "scoped-columns", "legacy-default", "rep-second"):
        return (record(**base, location="table:" + assertion["table"], detail="protected-rows-match"),)
    if kind == "exact-field":
        return (record(**base, location="field:" + assertion["field"], detail="exact-field-match", field=assertion["field"], value_role="metadata"),)
    if kind == "schema-column":
        return (record(**base, location="column:" + assertion["column"], detail="schema-column-match"),)
    if kind == "insert-shape":
        return (record(**base, location="insert_shape", detail="insert-shape-match"),
                record(**base, location="visible_value", detail="visible-match"))
    if kind == "binding-uniformity":
        return (record(**base, location="binding", detail="bound-to-requested-context"),)
    if kind == "commit-classification":
        return (record(**base, location="classification", detail="classification-contract-met", checked_classification="targeted_assertion_failed"),)
    raise PreparationError("unknown-identity-form")


def row_failure(case, assertion, version, row_id, field=None, expected=None, observed=None):
    table = assertion["table"]
    index = observation_index(assertion)
    locator = "call:" + str(index) + " table:" + table + " " + assertion["identity_column"] + ":" + str(row_id)
    if field is None:
        return (record(case, assertion["assertion_id"], version, index, table, "failed", locator,
                       "missing-protected-row", discrepancy_kind="row-absent", row_locator=locator),)
    return (record(case, assertion["assertion_id"], version, index, table, "failed", locator + " column:" + field,
                   "field-differs", discrepancy_kind="field-value", field=field, row_locator=locator,
                   value_role="stored", expected_value=expected, observed_value=observed),)


def insert_failure(case, assertion, version, visible):
    return diagnostic(case, assertion, version, "failed", "visible_value", "visible-differs",
                      discrepancy_kind="field-value", field="token_limit", value_role="stored",
                      expected_value=copy.deepcopy(assertion["visible_value"]), observed_value=visible)


def schema_failure(case, assertion, version):
    return diagnostic(case, assertion, version, "failed", "column:token_limit field:nullable", "schema-field-differs",
                      discrepancy_kind="field-value", field="nullable", value_role="schema-fact",
                      expected_value=True, observed_value=False)


def exact_failure(case, assertion, version):
    return diagnostic(case, assertion, version, "failed", "field:" + assertion["field"], "exact-field-differ",
                      discrepancy_kind="field-value", field=assertion["field"], value_role="metadata")


def identity_rows(constants, assertion):
    if assertion.get("rep_kind") == "no-new-change":
        key = "PRESERVATION_TASKS" if assertion["table"] == "background_tasks" else "PRESERVATION_USERS"
        return copy.deepcopy(constants[key])
    result = list(copy.deepcopy(assertion["expected_rows"]))
    column = assertion["identity_column"]
    companions = assertion.get("companion_identities", ())
    pool = constants["PRESERVATION_TASKS"] if assertion["table"] == "background_tasks" else constants["PRESERVATION_USERS"]
    for identifier in companions:
        candidates = [r for r in pool if type(r[column]) is type(identifier) and r[column] == identifier]
        if len(candidates) != 1:
            raise PreparationError("companion-not-unique")
        result.append(copy.deepcopy(candidates[0]))
    return tuple(result)


def insert_payload(mode):
    # V3 section 5.7 only. These literals are not additional catalog expectations.
    names = ("username", "email", "password_hash", "role")
    values = ("synth-insert-user", "synth-insert@example.test", "synth-insert-password-hash", "user")
    explicit = mode == "explicit-null"
    return {"table": "users", "insert_mode": mode, "column": "token_limit",
            "supplied_columns": names + (("token_limit",) if explicit else ()),
            "supplied_values": values + ((SQL_NULL,) if explicit else ()),
            "supplied_value": SQL_NULL if explicit else ("field-omitted",),
            "visible_value": SQL_NULL if explicit else 500000}


def make_observation(constants, case, assertions, version):
    obs = {"case_id": case["case_id"], "fixture_id": case["fixture_id"], "source_version": version}
    repeated = any(a["comparison_kind"] == "rep-second" for a in assertions)
    def put_rows(destination, assertion, rows):
        table = assertion["table"]
        tables = destination.setdefault("tables", {})
        if table not in tables:
            tables[table] = {"table": table, "rows": rows}
            return
        # Intact multi-assertion dispatcher: union identities, not duplicate rows.
        current = list(tables[table]["rows"])
        key = assertion["identity_column"]
        for item in rows:
            old = [r for r in current if type(r[key]) is type(item[key]) and r[key] == item[key]]
            if not old:
                current.append(item)
            elif len(old) != 1 or not same_exact(old[0], item):
                raise PreparationError("contradictory-identity-input")
        tables[table]["rows"] = tuple(current)
    for a in assertions:
        kind = a["comparison_kind"]
        if kind == "rep-second":
            indexes = (1, 2) if a["rep_kind"] == "no-new-change" else (a["call_index"],)
            rows = identity_rows(constants, a)
            for index in indexes:
                name = "call_" + str(index)
                call = obs.setdefault(name, {"case_id": case["case_id"], "fixture_id": case["fixture_id"], "source_version": version, "call_index": index})
                put_rows(call, a, rows)
            continue
        if repeated:
            raise PreparationError("unexpected-mixed-case-form")
        if "call_index" in obs and obs["call_index"] != a["call_index"]:
            raise PreparationError("mixed-ordinary-index")
        obs["call_index"] = a["call_index"]
        if kind in ("protected-rows", "scoped-columns", "legacy-default"):
            put_rows(obs, a, identity_rows(constants, a))
        elif kind == "exact-field":
            obs[a["field"]] = copy.deepcopy(a["expected_value"])
        elif kind == "schema-column":
            obs["schema"] = {a["table"]: {"columns": copy.deepcopy(constants["SCHEMA_USERS_COLUMNS"])}}
        elif kind == "insert-shape":
            obs["insert"] = insert_payload(a["insert_mode"])
        elif kind == "binding-uniformity":
            obs["envelopes"] = ({k: obs[k] for k in ("case_id", "fixture_id", "source_version", "call_index")},)
        elif kind == "commit-classification":
            obs["classification"] = "targeted_assertion_failed"
            obs["missing_tables"] = False
        else:
            raise PreparationError("unknown-observation-form")
    return obs


def row_payload(obs, assertion):
    if assertion["comparison_kind"] == "rep-second":
        return obs["call_" + str(assertion["call_index"])]["tables"][assertion["table"]]
    return obs["tables"][assertion["table"]]


def remove_row(obs, assertion, identifier):
    payload = row_payload(obs, assertion)
    key = assertion["identity_column"]
    rows = payload["rows"]
    selected = [r for r in rows if type(r[key]) is type(identifier) and r[key] == identifier]
    if len(selected) != 1:
        raise PreparationError("row-removal-not-unique")
    payload["rows"] = tuple(r for r in rows if r is not selected[0])


def change_cell(obs, assertion, identifier, field, value):
    payload = row_payload(obs, assertion)
    selected = [r for r in payload["rows"] if type(r[assertion["identity_column"]]) is type(identifier) and r[assertion["identity_column"]] == identifier]
    if len(selected) != 1:
        raise PreparationError("row-change-not-unique")
    selected[0][field] = value


def apply_base_discrepancy(case, assertion, obs, version):
    matches = [p for p in case["base_regression_patterns"] if p["assertion_id"] == assertion["assertion_id"]]
    if len(matches) != 1:
        raise PreparationError("pattern-not-unique")
    p = matches[0]
    if p["discrepancy_kind"] == "row-absent":
        remove_row(obs, assertion, p["row_identity"])
        return row_failure(case, assertion, version, p["row_identity"])
    change_cell(obs, assertion, p["row_identity"], p["field"], copy.deepcopy(p["observed_value"]))
    return row_failure(case, assertion, version, p["row_identity"], p["field"], copy.deepcopy(p["expected_value"]), copy.deepcopy(p["observed_value"]))


def normal_dispatch_expected(case, version):
    records = []
    for a in case["assertions"]:
        records.extend(identity_expected(case, a, version))
    detail = "not-a-base-regression" if "base_regression_patterns" in case else "no-pattern-declared"
    records.extend(regression(case, version, detail=detail))
    return expected_sort(records)


INHERITED_SOURCE_VERSION = {
    1: "A1",
    2: "BASE",
    3: "BASE",
    4: "A1",
    5: "BASE",
    6: "BASE",
    7: "A1",
    8: "BASE",
    9: "BASE",
    10: "A1",
    11: "BASE",
    12: "BASE",
    13: "A1",
    14: "BASE",
    15: "A1",
    16: "BASE",
    17: "A1",
    18: "BASE",
    19: "A1",
    20: "BASE",
    21: "A1",
    22: "BASE",
    23: "A1",
    24: "BASE",
    25: "BASE",
    26: "A1",
    27: "BASE",
    28: "BASE",
    29: "A1",
    30: "BASE",
    31: "A1",
    32: "BASE",
    33: "A1",
    34: "BASE",
    35: "A1",
    36: "BASE",
    37: "A1",
    38: "BASE",
    39: "A1",
    40: "BASE",
    41: "A1",
    42: "BASE",
    43: "A1",
    44: "BASE",
    45: "A1",
    46: "BASE",
    47: "A1",
    48: "BASE",
    49: "A1",
    50: "BASE",
    51: "A1",
    52: "BASE",
    53: "A1",
    54: "BASE",
    55: "A1",
    56: "BASE",
    57: "A1",
    58: "BASE",
    59: "A1",
    60: "BASE",
    61: "A1",
    62: "BASE",
    63: "A1",
    64: "BASE",
    65: "A1",
    66: "BASE",
    67: "A1",
    68: "BASE",
    69: "A1",
    70: "BASE",
    71: "A1",
    72: "BASE",
    73: "BASE",
    74: "A1",
    75: "BASE",
    76: "BASE",
    77: "A1",
    78: "BASE",
    79: "BASE",
    80: "A1",
    81: "BASE",
    82: "BASE",
    83: "A1",
    84: "BASE",
    85: "BASE",
    86: "A1",
    87: "BASE",
    88: "BASE",
    89: "A1",
    90: "BASE",
    91: "BASE",
    92: "A1",
    93: "BASE",
    94: "BASE",
    95: "A1",
    96: "BASE",
    97: "BASE",
    98: "A1",
    99: "BASE",
    100: "BASE",
    101: "A1",
    102: "BASE",
    103: "BASE",
    104: "A1",
    105: "BASE",
    106: "BASE",
    107: "A1",
    108: "BASE",
    109: "A1",
    110: "BASE",
    111: "A1",
    112: "BASE",
    113: "A1",
    114: "BASE",
    115: "A1",
    116: "BASE",
    117: "A1",
    118: "BASE",
    119: "A1",
    120: "A1",
    121: "A1",
    122: "A1",
    123: "A1",
    124: "A1",
    125: "A1",
    126: "A1",
    127: "A1",
    128: "A1",
    129: "A1",
    130: "A1",
    131: "A1",
    132: "A1",
    133: "A1",
    134: "A1",
    135: "A1",
    136: "A1",
    137: "A1",
    138: "A1",
    139: "A1",
    140: "A1",
    141: "A1",
    142: "A1",
    143: "A1",
    144: "A1",
    145: "A1",
    146: "A1",
    147: "A1",
    148: "A1",
    149: "A1",
    150: "A1",
    151: "A1",
    152: "A1",
    153: "A1",
    154: "A1",
    155: "A1",
    156: "A1",
    157: "A1",
    158: "A1",
    159: "A1",
    160: "A1",
    161: "A1",
    162: "A1",
    163: "A1",
    164: "A1",
    165: "A1",
    166: "A1",
    167: None,
    168: None,
    169: "A1",
    170: "A1",
    171: "A1",
    172: "A1",
    173: None,
    174: None,
    175: "A1",
    176: "A1",
    177: "A1",
    178: "A1",
    179: None,
    180: None,
    181: "A1",
    182: "BASE",
    183: "BASE",
    184: "BASE",
    185: "BASE",
    186: "BASE",
    187: "A1",
    188: "A1",
    189: "A1",
    190: "A1",
    191: "A1",
    192: "A1",
    193: "A1",
    194: "A1",
    195: "A1",
    196: "A1",
    197: "A1",
    198: "A1",
    199: "A1",
    200: "A1",
    201: "A1",
    202: "A1",
    203: "BASE",
    204: "BASE",
    205: "BASE",
    206: "BASE",
    207: "BASE",
    208: "BASE",
    209: "BASE",
    210: "BASE",
    211: "BASE",
    212: "BASE",
    213: "BASE",
    214: "BASE",
    215: "BASE",
    216: "BASE",
    217: "BASE",
    218: "BASE",
    219: "BASE",
    220: "BASE",
    221: "BASE",
    222: "A1",
    223: "A1",
    224: "A1",
    225: "A1",
    226: "A1",
    227: "A1",
    228: "A1",
    229: "A1",
    230: "A1",
    231: "A1",
    232: "A1",
    233: "A1",
    234: "A1",
    235: "A1",
    236: "A1",
    237: "A1",
    238: "A1",
    239: "A1",
}

DECLARATION_SOURCE = {
    "D-ABSENT": ("REP-SECOND.call-1", "delete-table", "ASSERT-REP-CALL1-OLD-DONE-PRESENT"),
    "D-NONE": ("RET-RECENT.done", "table-none", "ASSERT-RET-RECENT-DONE-PRESENT"),
    "D-INT": ("RET-RECENT.done", "table-int", "ASSERT-RET-RECENT-DONE-PRESENT"),
    "D-EMPTY": ("RET-RECENT.done", "table-empty", "ASSERT-RET-RECENT-DONE-PRESENT"),
    "D-SUB": ("RET-RECENT.done", "table-sub", "ASSERT-RET-RECENT-DONE-PRESENT"),
    "CHK-D-01-table-deleted-copy": ("RET-RECENT.done", "delete-table", "ASSERT-RET-RECENT-DONE-PRESENT"),
    "CHK-D-02-table-deleted-copy": ("SCH-EXPLICIT-NULL.omitted-column", "delete-table", "ASSERT-SCH-OMITTED-COLUMN-VISIBLE-500000"),
    "CHK-D-03-table-deleted-copy": ("SCH-FRESH.token-limit-column", "delete-table", "ASSERT-SCH-FRESH-TOKEN-LIMIT-COLUMN"),
}
INTACT_SOURCE = {
    "INTACT-REP": "REP-SECOND.call-1",
    "INTACT-NONEW": "REP-SECOND.no-new-change",
    "INTACT-RECENT": "RET-RECENT.done",
    "INTACT-NEG": "NEG-PAIR.cross-binding",
}


def selection_ids():
    """Accepted V4 schedule. Rank order, not numeric-ID order."""
    ids = ["R13-V-" + str(i).zfill(4) for i in range(1, 266)]
    ids.append("R13-V-0283")
    ids.extend("R13-V-" + str(i).zfill(4) for i in range(266, 283))
    ids.extend("R13-V-" + str(i).zfill(4) for i in range(284, 289))
    return tuple(ids)


def recipe_of(input_ref):
    marker = " recipe "
    if marker in input_ref:
        return input_ref.split(marker, 1)[1]
    return ""


def vector_number(vector_id):
    return int(vector_id.rsplit("-", 1)[-1])


def correspondence(csv_text, projection):
    """One-to-one check of the runtime projection against the frozen CSV.

    The CSV stays in ID order. The projection is selection_rank order.
    Derived fields are checked, not used as a second selection list.
    """
    reader = csv.DictReader(io.StringIO(csv_text))
    if tuple(reader.fieldnames or ()) != CSV_FIELDS:
        raise PreparationError("ledger-columns")
    csv_rows = list(reader)
    if len(csv_rows) != PLANNED or len(projection) != PLANNED:
        raise PreparationError("ledger-count")
    by_id = {}
    for row in csv_rows:
        if row["vector_id"] in by_id:
            raise PreparationError("duplicate-vector")
        by_id[row["vector_id"]] = row
    if tuple(item["vector_id"] for item in projection) != selection_ids():
        raise PreparationError("selection-schedule")
    normalized = []
    seen_rank = set()
    for index, item in enumerate(projection):
        source = by_id.get(item["vector_id"])
        if source is None:
            raise PreparationError("projection-not-in-csv")
        for key in CSV_FIELDS:
            if item.get(key) != source[key]:
                raise PreparationError("projection-cell")
        rank = int(source["selection_rank"])
        if rank != index + 1 or rank in seen_rank:
            raise PreparationError("selection-rank")
        seen_rank.add(rank)
        derived = item.get("derived")
        if type(derived) is not dict:
            raise PreparationError("derived-shape")
        deps = tuple(part for part in source["dependency_ids"].split(";") if part)
        if tuple(derived.get("dependencies", ())) != deps:
            raise PreparationError("derived-dependencies")
        if derived.get("recipe") != recipe_of(source["input_ref"]):
            raise PreparationError("derived-recipe")
        number = vector_number(source["vector_id"])
        if number <= 239:
            version = INHERITED_SOURCE_VERSION[number]
        else:
            version = None
        if derived.get("source_version") != version:
            raise PreparationError("derived-version")
        if source["entrypoint"] not in CALLED_NAMES:
            raise PreparationError("entrypoint")
        row = dict(source)
        row["id"] = source["vector_id"]
        row["check_id"] = source["check_group"]
        row["dependencies"] = deps
        row["recipe"] = derived["recipe"]
        row["source_version"] = version
        row["case_id"] = source["case_id"] or None
        row["assertion_id"] = source["assertion_id"] or None
        normalized.append(row)
    if len(by_id) != PLANNED or seen_rank != set(range(1, PLANNED + 1)):
        raise PreparationError("ledger-identity")
    counts = {}
    groups = set()
    earlier = set()
    for row in normalized:
        counts[row["entrypoint"]] = counts.get(row["entrypoint"], 0) + 1
        groups.add(row["check_group"])
        for dep in row["dependencies"]:
            if dep not in earlier:
                raise PreparationError("nonpreceding-dependency")
        earlier.add(row["id"])
    if counts != EXPECTED_ENTRY_COUNTS or len(groups) != CHECK_GROUPS:
        raise PreparationError("entrypoint-or-group-count")
    return tuple(normalized)


def materialize_shared(decl, catalog):
    source_id, kind, assertion_id = DECLARATION_SOURCE[decl]
    case = copy.deepcopy(catalog[source_id])
    selected = [item for item in case["assertions"] if item["assertion_id"] == assertion_id]
    if len(selected) != 1 or "table" not in selected[0]:
        raise PreparationError("declaration-table")
    if kind == "delete-table":
        del selected[0]["table"]
    elif kind == "table-none":
        selected[0]["table"] = None
    elif kind == "table-int":
        selected[0]["table"] = 7
    elif kind == "table-empty":
        selected[0]["table"] = ""
    elif kind == "table-sub":
        selected[0]["table"] = passive_text("background_tasks")
    else:
        raise PreparationError("declaration-kind")
    return case


def case_for(row, catalog, shared):
    decl = row["declaration_ref"]
    if decl == "catalog":
        if row["case_id"] is None:
            return None
        return copy.deepcopy(catalog[row["case_id"]])
    if decl in INTACT_SOURCE:
        if row["case_id"] != INTACT_SOURCE[decl]:
            raise PreparationError("intact-case-ancestry")
        case = copy.deepcopy(catalog[INTACT_SOURCE[decl]])
        if case["case_id"] != catalog[INTACT_SOURCE[decl]]["case_id"]:
            raise PreparationError("intact-identity")
        return case
    if decl not in DECLARATION_SOURCE:
        raise PreparationError("unknown-declaration")
    if row["case_id"] != DECLARATION_SOURCE[decl][0]:
        raise PreparationError("declaration-case-ancestry")
    if decl not in shared:
        shared[decl] = materialize_shared(decl, catalog)
    return shared[decl]


def one_assertion(case, assertion_id):
    matches = [item for item in case["assertions"] if item["assertion_id"] == assertion_id]
    if len(matches) != 1:
        raise PreparationError("assertion-selection")
    return matches[0]


def require_case(case, case_id, fixture_id):
    if case["case_id"] != case_id or case["fixture_id"] != fixture_id:
        raise PreparationError("case-binding")
    return case


def t_base(**replacements):
    value = record(
        {"case_id": "REP-SECOND.call-1", "fixture_id": "FIX-PRESERVATION-PREPARED"},
        "ASSERT-REP-CALL1-OLD-DONE-PRESENT", "A1", "unavailable", "",
        "observation_unavailable", "table", "field-absent:table",
    )
    value.update(replacements)
    return value


def t_false(**replacements):
    value = t_base()
    value["call_index"] = "rejected"
    value.update(replacements)
    return value


def t_outer(**replacements):
    value = t_base()
    value.update(
        status="malformed_input", call_index="rejected", location="call_index",
        detail="outer-call-index-collapses-sequence",
    )
    value.update(replacements)
    return value


def e_val(injected, status, location, detail):
    """Written E-VAL. Association strings come from the written input, not a target return."""
    if status not in ("malformed_input", "observation_unavailable"):
        raise PreparationError("eval-status")

    def text_of(key):
        value = injected.get(key, "")
        return value if type(value) is str else ""

    call = injected.get("call_index", "unavailable")
    if type(call) is bool or not (type(call) is int or call in ("1|2", "case", "unavailable", "rejected")):
        call = "unavailable"
    subject = {"case_id": text_of("case_id"), "fixture_id": text_of("fixture_id")}
    return (record(
        subject, text_of("assertion_id"), text_of("source_version"), call, text_of("table"),
        status, location, detail,
        pattern_match="malformed_input" if status == "malformed_input" else "unavailable",
        case_regression="unavailable",
    ),)


def e_copy(template):
    """Independent expected shape. Not a copy of a future actual return."""
    item = copy.deepcopy(template)
    if item.get("source_version") == "A1":
        item["pattern_match"] = "not_applicable"
    return (item,)


def fresh(catalog, case_id):
    return copy.deepcopy(catalog[case_id])


def rep_identity_obs(constants, catalog):
    case = fresh(catalog, "REP-SECOND.call-1")
    obs = make_observation(constants, case, case["assertions"], "A1")
    if "call_index" in obs or "call_2" in obs or "call_1" not in obs:
        raise PreparationError("rep-identity-shape")
    return obs


def outer_obs(constants, catalog):
    obs = rep_identity_obs(constants, catalog)
    obs["call_index"] = 1
    if type(obs["call_index"]) is not int:
        raise PreparationError("outer-call-index")
    return obs


def class_env(constants, catalog):
    return rep_identity_obs(constants, catalog)


def call_env(constants, catalog):
    case = fresh(catalog, "REP-SECOND.no-new-change")
    obs = make_observation(constants, case, case["assertions"], "A1")
    if "call_index" in obs or "call_1" not in obs or "call_2" not in obs:
        raise PreparationError("call-env-shape")
    return obs


def row_obs(constants, catalog):
    case = fresh(catalog, "RET-RECENT.done")
    return make_observation(constants, case, case["assertions"], "A1")


def blank_spec(row):
    return {"row": row, "case": None, "assertion": None, "obs": None, "mode": "producer"}


def recent_false():
    return t_false(
        assertion_id="ASSERT-RET-RECENT-DONE-PRESENT",
        case_id="RET-RECENT.done",
        fixture_id="FIX-PRESERVATION-PREPARED",
    )


def nonew_marker(call_index, detail):
    return t_base(
        assertion_id="ASSERT-REP-NO-NEW-TASK-CHANGE",
        case_id="REP-SECOND.no-new-change",
        status="malformed_input",
        call_index=call_index,
        location="call_index",
        detail=detail,
    )


def record_0283(case):
    return record(
        case, "ASSERT-RET-RECENT-DONE-PRESENT", "A1", "rejected", "",
        "malformed_input", "call_index", "call-index-type",
    )


def record_0267():
    return record(
        {"case_id": "NEG-PAIR.cross-binding", "fixture_id": "FIX-BINDING-RULE"},
        "", "A1", "rejected", "", "malformed_input", "expected-context", "context-invalid",
    )


def finish_spec(s, expected, n):
    if expected is None:
        raise PreparationError("missing-frozen-expectation")
    s["expected"] = copy.deepcopy(expected)
    mode = s["mode"]
    if mode == "utility":
        kind = "synthetic-value"
    elif mode in ("annotate_injected", "classify_injected"):
        kind = "injected-record"
    elif mode in ("annotate_raw", "classify_raw"):
        kind = "producer-output"
    elif n == 220:
        kind = "mixed-producer-and-injected-control"
    elif mode == "classify_controls":
        kind = "producer-output"
    else:
        kind = "synthetic-observation"
    s["input_kind"] = kind
    s["case_snapshot"] = graph_snapshot(s["case"]) if s["case"] is not None else None
    return s


def build_inherited(row, catalog, constants, shared):
    n = vector_number(row["id"])
    version = row["source_version"] or ""
    if row["declaration_ref"] != "catalog":
        raise PreparationError("inherited-declaration")
    c = a = obs = None
    if row["case_id"] is not None:
        source_case = catalog[row["case_id"]]
        shared_key = "B12" if n in (163, 164) else None
        if shared_key is not None:
            if shared_key not in shared:
                shared[shared_key] = copy.deepcopy(source_case)
            c = shared[shared_key]
        else:
            c = copy.deepcopy(source_case)
        if row["assertion_id"] is not None:
            a = one_assertion(c, row["assertion_id"])
        selected_inputs = c["assertions"] if row["entrypoint"] == "compare_supplied_case" else tuple(
            q for q in c["assertions"] if q["assertion_id"] == row["assertion_id"]
        )
        obs = make_observation(constants, c, selected_inputs, version)
    s = {"row": row, "case": c, "assertion": a, "obs": obs, "mode": "producer"}
    expected = identity_expected(c, a, version) if a is not None else None
    def local_diagnostic():
        del obs["call_1"]["tables"]["background_tasks"]
        return diagnostic(c, a, version, "observation_unavailable", "call:1 table:background_tasks", "table-absent:background_tasks", call_index=1)

    def commit_refusal():
        obs["classification"] = "uncommitted_work"
        obs["missing_tables"] = True
        return diagnostic(c, a, version, "failed", "classification", "missing-tables-are-not-uncommitted-work", checked_classification="uncommitted_work")

    def inject_classification(injected, status, location, detail):
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        return regression(c, version, status, location, detail, "unavailable")

    # X-0001..X-0118: Group A. BASE annotation has a separate external call.
    if n <= 118:
        if row["recipe"] == "catalog-base-discrepancy":
            expected = apply_base_discrepancy(c, a, obs, version)
        elif row["recipe"] == "catalog-annotation":
            expected = apply_base_discrepancy(c, a, obs, version)
            expected[0]["pattern_match"] = "yes"
            s["mode"] = "annotate_raw"
        elif row["recipe"] != "catalog-identity":
            raise PreparationError("unknown-catalog-recipe")

    # X-0119..X-0135: thirteen refusal groups / seventeen external calls.
    elif n in (119, 206, 218):
        identifier = "synth-task-old-done" if n == 206 else "synth-task-recent-done"
        remove_row(obs, a, identifier)
        expected = row_failure(c, a, version, identifier)
    elif n == 120:
        change_cell(obs, a, 101, "token_limit", 1)
        expected = row_failure(c, a, version, 101, "token_limit", 0, 1)
    elif n == 121:
        # H2 selection outside V3: user 201 completes this input. V3 does not
        # name 201. Row 202 stays the catalog identity. This comment is not a run.
        change_cell(obs, a, 201, "token_limit", 500001)
        expected = row_failure(c, a, version, 201, "token_limit", 500000, 500001)
    elif n == 122:
        columns = obs["schema"]["users"]["columns"]
        selected = [column for column in columns if column["name"] == "token_limit"]
        if len(selected) != 1:
            raise PreparationError("schema-selection")
        selected[0]["nullable"] = False
        expected = schema_failure(c, a, version)
    elif n in (123, 125):
        visible = 500001 if n == 123 else 500000
        obs["insert"]["visible_value"] = visible
        expected = insert_failure(c, a, version, visible)
    elif n == 124:
        obs["insert"]["supplied_columns"] += ("token_limit",)
        obs["insert"]["supplied_values"] += (1,)
        expected = diagnostic(c, a, version, "malformed_input", "insert", "omission-also-supplies-column")
    elif n == 126:
        obs["table_names"] = ("background_tasks",)
        expected = exact_failure(c, a, version)
    elif n in (127, 156):
        injected = identity_expected(c, a, version)[0]
        injected["table"] = "benchmarks"
        expected = inject_classification(injected, "malformed_input", "outcome:table", "table-binding-conflict")
    elif n == 128:
        pass  # Fresh identity call_1; call_2 stays absent.
    elif n == 129:
        obs["call_2"] = obs.pop("call_1")
        obs["call_2"]["call_index"] = 2
        expected = diagnostic(c, a, version, "observation_unavailable", "call_1", "call-record-absent")
    elif n in (130, 165, 190):
        expected = local_diagnostic()
    elif n == 131:
        injected = identity_expected(c, a, version)[0]
        injected["call_index"] = 1
        expected = inject_classification(injected, "malformed_input", "outcome:call_index", "call-index-mismatch")
    elif n == 132:
        del obs["call_2"]
        expected = diagnostic(c, a, version, "observation_unavailable", "call_2", "call-record-absent")
    elif n in (133, 134):
        field = "case_id" if n == 133 else "fixture_id"
        obs["envelopes"][0][field] = "RET-RECENT.done" if n == 133 else "FIX-FRESH-SCHEMA"
        expected = diagnostic(c, a, version, "malformed_input", "observation-index:0 field:" + field, "binding-mismatch")
    elif n in (135, 153):
        expected = commit_refusal()

    # X-0136..X-0146: intact WHOLE-case dispatcher, not single-assertion copies.
    elif 136 <= n <= 146:
        s["mode"] = "dispatch"
        expected = normal_dispatch_expected(c, version)

    # X-0147..X-0166: table applicability / classification evidence.
    elif n in (147, 149, 151, 155, 163):
        pass
    elif n in (148, 150, 152, 154, 164):
        s["mode"] = "classify_raw"
        expected = regression(c, version)
    elif n == 157:
        del obs["tables"]
        expected = diagnostic(c, a, version, "observation_unavailable", "table:background_tasks", "field-absent:tables")
    elif n in (158, 159, 160):
        if n == 159:
            obs["tables"]["background_tasks"] = None
            detail = "table-is-none:background_tasks"
        else:
            obs["tables"]["background_tasks"]["table"] = "users" if n == 158 else passive_text("background_tasks")
            detail = "table-binding-conflict:background_tasks"
        expected = diagnostic(c, a, version, "malformed_input", "table:background_tasks", detail)
    elif n == 161:
        obs["tables"]["benchmarks"]["rows"] = ()
        expected = expected_sort([row_failure(c, a, version, r["sector"])[0] for r in a["expected_rows"]])
    elif n == 162:
        s["mode"] = "classify_injected"
        s["injected"] = ()
        expected = regression(c, version, "observation_unavailable", "outcome:ASSERT-SCH-FRESH-TABLES-OMITTED", "field-absent:assertion-outcome", "unavailable")
    elif n == 166:
        s["mode"] = "classify_raw"
        expected = regression(c, version, "observation_unavailable", "outcome:ASSERT-REP-NO-NEW-TASK-CHANGE", "field-absent:assertion-outcome", "unavailable")

    # X-0167..X-0223: utility contracts; no extra call for helper validation.
    elif n in (167, 168):
        s["mode"] = "utility"
        s["args"] = ({}, ("assertion_id",)) if n == 167 else ({"assertion_id": None}, ("assertion_id",))
        status = "observation_unavailable" if n == 167 else "malformed_input"
        detail = "field-absent:assertion_id" if n == 167 else "field-is-none:assertion_id"
        expected = (record(None, "", "", "unavailable", "", status, "field:assertion_id", detail),)
    elif n == 169:
        obs["table_names"] = {}
        expected = diagnostic(c, a, version, "malformed_input", "field:table_names", "unsupported")
    elif n in (170, 171, 172):
        obs["call_index"] = {170: True, 171: 1.0, 172: "1"}[n]
        expected = diagnostic(c, a, version, "malformed_input", "call_index", "call-index-type", call_index="rejected", table="")
    elif n in (173, 174):
        s["mode"] = "utility"
        s["args"] = (SQL_NULL, None if n == 173 else ["sql-null"])
        expected = False
    elif n in (175, 176):
        obs["insert"]["visible_value"] = None if n == 175 else ["sql-null"]
        detail = "field-is-none:visible_value" if n == 175 else "visible:cell-composite"
        expected = diagnostic(c, a, version, "malformed_input", "insert", detail)
    elif n == 177:
        item = copy.deepcopy(a["expected_rows"][0])
        obs["tables"]["background_tasks"]["rows"] = (item, copy.deepcopy(item))
        expected = diagnostic(c, a, version, "malformed_input", "row-index:1 column:task_id", "duplicate-identity")
    elif n == 178:
        wanted = ("synth-task-recent-done", "synth-task-recent-error")
        rows = constants["PRESERVATION_TASKS"]
        obs["tables"]["background_tasks"]["rows"] = tuple(copy.deepcopy(next(r for r in rows if r["task_id"] == name)) for name in wanted)
    elif n == 179:
        # Assignment constructs within-operand sharing, not cross-operand identity.
        left_child = {"n": 1}
        right_child = {"n": 1}
        left = {"a": left_child, "b": left_child}
        right = {"a": right_child, "b": right_child}
        s["mode"] = "utility"
        s["args"] = (left, right)
        expected = True
    elif n == 180:
        cycle = {}
        cycle["self"] = cycle
        s["mode"] = "utility"
        s["args"] = (cycle, cycle)
        expected = False
    elif n == 181:
        value = []
        value.append(value)
        obs["table_names"] = value
        expected = diagnostic(c, a, version, "malformed_input", "field:table_names", "metadata-item")
    elif 182 <= n <= 186:
        mutations = {
            182: ("case_id", "RET-RECENT.error", "binding-mismatch"),
            183: ("fixture_id", "FIX-FRESH-SCHEMA", "binding-mismatch"),
            184: ("source_version", "A1", "version"),
            185: ("assertion_id", "ASSERT-RET-RECENT-ERROR-PRESENT", "binding-mismatch"),
            186: ("call_index", 2, "call-index-mismatch"),
        }
        field, wrong, detail = mutations[n]
        injected = identity_expected(c, a, version)[0]
        injected[field] = wrong
        expected = inject_classification(injected, "malformed_input", "outcome:" + field, detail)
    elif n in (187, 188, 189, 192):
        pass
    elif n in (191, 193):
        # Only the separately supplied assertion copy changes, not c's declarations.
        a = copy.deepcopy(a)
        s["assertion"] = a
        if n == 191:
            del a["rep_kind"]
        else:
            a["rep_kind"] = None
        status = "observation_unavailable" if n == 191 else "malformed_input"
        detail = "field-absent:rep_kind" if n == 191 else "field-is-none:rep_kind"
        expected = diagnostic(c, a, version, status, "rep_kind", detail, call_index="unavailable")
    elif 194 <= n <= 197:
        if n == 194:
            del obs["envelopes"]
        else:
            obs["envelopes"] = {195: None, 196: (), 197: {}}[n]
        status, detail = {
            194: ("observation_unavailable", "field-absent:envelopes"),
            195: ("malformed_input", "field-is-none:envelopes"),
            196: ("observation_unavailable", "envelopes-empty"),
            197: ("malformed_input", "envelopes-type"),
        }[n]
        expected = diagnostic(c, a, version, status, "envelopes", detail)
    elif 198 <= n <= 200:
        if n == 198:
            injected = row_failure(c, a, version, "synth-task-recent-done", "status", "done", "error")[0]
            injected["value_role"] = "schema-fact"
        elif n == 199:
            injected = schema_failure(c, a, version)[0]
            injected["value_role"] = "metadata"
        else:
            injected = exact_failure(c, a, version)[0]
            injected["value_role"] = "stored"
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = validation(injected, "malformed_input", "outcome-index:0:value_role", "value-role-conflict")
    elif n == 201:
        injected = diagnostic(c, a, version, "observation_unavailable", "field:table_names", "field-absent:table_names", value_role="metadata", expected_value=1)[0]
        del injected["case_id"]
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = validation(injected, "observation_unavailable", "outcome-index:0:case_id", "field-absent:subject-context")
    elif n == 202:
        injected = record(None, "", "", "unavailable", "", "malformed_input", "assertion", "assertion-type")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = (copy.deepcopy(injected),)
    elif n in (203, 204, 205, 221, 222):
        injected = row_failure(c, a, version, "synth-task-old-done")[0]
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        if n == 203:
            del injected["row_locator"]
            expected = validation(injected, "observation_unavailable", "outcome-index:0:row_locator", "field-absent:row_locator")
        elif n == 204:
            injected["row_locator"] = ""
            expected = validation(injected, "malformed_input", "outcome-index:0:row_locator", "locator")
        else:
            if n == 205:
                injected["row_locator"] = "other-locator"
            expected = (copy.deepcopy(injected),)
            expected[0]["pattern_match"] = "no" if n == 205 else ("yes" if n == 221 else "not_applicable")
    elif 207 <= n <= 216:
        pass  # Each control is its own BASE producer call on its own case.
    elif n in (217, 219, 220):
        s["mode"] = "classify_controls"
        if n == 217:
            s["control_ids"] = tuple("R13-V-" + str(k).zfill(4) for k in range(207, 217))
            expected = regression(c, version, detail="exact-pattern-and-controls", regression_state="yes")
        elif n == 219:
            s["control_ids"] = ("R13-V-0218",) + tuple("R13-V-" + str(k).zfill(4) for k in range(208, 217))
            expected = regression(c, version, "failed", "case-regression", "pattern-not-exact", "no")
        else:
            s["control_ids"] = tuple("R13-V-" + str(k).zfill(4) for k in range(208, 217))
            s["fake_control"] = {
                "case_id": "RET-OLD-TERMINAL.done", "assertion_id": "CASE-REGRESSION",
                "fixture_id": "FIX-PRESERVATION-PREPARED", "source_version": "BASE",
                "call_index": "case", "table": "", "status": "passed", "result_role": "case-regression",
            }
            expected = regression(c, version, "malformed_input", "control:call_index", "call-index-type", "unavailable")
    elif n == 223:
        obs["tables"]["users"]["rows"] = (copy.deepcopy(a["expected_rows"][0]),)
        s["inspect_secrets"] = True
    return finish_spec(s, expected, n)


def build_block_b(row, catalog, constants, shared):
    """V4 section 6. One R13 expectation. Not an H2 characterization alternative."""
    n = vector_number(row["id"])
    version = "A1"
    c = case_for(row, catalog, shared)
    a = one_assertion(c, row["assertion_id"])
    source_case = fresh(catalog, row["case_id"])
    if row["entrypoint"] == "compare_supplied_case" or n == 238:
        selected = source_case["assertions"]
    else:
        selected = tuple(item for item in source_case["assertions"] if item["assertion_id"] == row["assertion_id"])
    obs = make_observation(constants, source_case, selected, version)
    if n == 238 and ("call_index" in obs or "call_2" in obs or "call_1" not in obs):
        raise PreparationError("class-env-shape")
    s = {"row": row, "case": c, "assertion": a, "obs": obs, "mode": "producer"}
    call_index = "unavailable" if n >= 236 else 1
    pred = record(c, a["assertion_id"], version, call_index, "", "observation_unavailable", "table", "field-absent:table")
    annotation_expected = validation(pred, "observation_unavailable", "table", "field-absent:table")
    classified = regression(c, version, "observation_unavailable", "table", "field-absent:table", "unavailable")
    if row["entrypoint"] == "separate_base_regression_metadata":
        s["mode"] = "annotate_raw"
        expected = annotation_expected
    elif row["entrypoint"] == "classify_case_regression":
        s["mode"] = "classify_raw"
        expected = classified
    elif row["entrypoint"] == "compare_supplied_case":
        s["mode"] = "dispatch"
        records = []
        if n == 239:
            for other in c["assertions"]:
                if other["assertion_id"] != a["assertion_id"]:
                    records.extend(identity_expected(c, other, version))
        records.extend(annotation_expected)
        records.extend(classified)
        expected = expected_sort(records)
        if n == 239 and tuple(item["assertion_id"] for item in expected) != REP_ASSERTIONS:
            raise PreparationError("dispatch-0239-order")
    else:
        expected = (pred,)
    return finish_spec(s, expected, n)


def build_block_c(row, catalog, constants, shared):
    """V4 section 8. Expectations are written templates, frozen before target calls."""
    n = vector_number(row["id"])
    s = blank_spec(row)
    c = None if n == 267 else case_for(row, catalog, shared)
    s["case"] = c

    if n == 240:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        s["assertion"] = one_assertion(c, "ASSERT-REP-CALL1-OLD-DONE-PRESENT")
        s["obs"] = outer_obs(constants, catalog)
        expected = (t_outer(),)
    elif n == 241:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        s["mode"] = "annotate_raw"
        expected = e_copy(t_outer())
    elif n == 242:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_outer()
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-type", "unavailable")
    elif n == 243:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        s["mode"] = "dispatch"
        s["obs"] = outer_obs(constants, catalog)
        records = []
        for assertion_id in REP_ASSERTIONS[:-1]:
            item = t_outer()
            item["assertion_id"] = assertion_id
            records.append(item)
        records.extend(regression(
            c, "A1", "malformed_input", "call_index", "outer-call-index-collapses-sequence", "unavailable",
        ))
        expected = expected_sort(records)
        if tuple(item["assertion_id"] for item in expected) != REP_ASSERTIONS:
            raise PreparationError("dispatch-0243-order")
    elif n in (244, 245, 246, 247):
        require_case(c, "RET-RECENT.done", "FIX-PRESERVATION-PREPARED")
        s["assertion"] = one_assertion(c, "ASSERT-RET-RECENT-DONE-PRESENT")
        s["obs"] = row_obs(constants, catalog)
        if n == 247 and type(s["assertion"]["table"]) is str:
            raise PreparationError("subclass-required")
        detail = "field-is-none:table" if n == 244 else "table"
        expected = (record(c, s["assertion"]["assertion_id"], "A1", 1, "", "malformed_input", "table", detail),)
    elif n in (248, 276, 277, 278):
        if n == 278 and type(one_assertion(c, "ASSERT-RET-RECENT-DONE-PRESENT")["table"]) is str:
            raise PreparationError("subclass-required")
        injected = recent_false()
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        detail = "field-is-none:table" if n == 248 else "table"
        expected = e_val(injected, "malformed_input", "table", detail)
    elif n == 249:
        injected = t_false()
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:call_index", "call-index-type")
    elif n == 250:
        injected = t_false()
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-type", "unavailable")
    elif n == 251:
        injected = t_false(call_index=2)
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:call_index", "call-index-mismatch")
    elif n == 252:
        injected = t_false(call_index=2)
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-mismatch", "unavailable")
    elif n == 253:
        injected = t_base(pattern_match=None)
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:pattern_match", "pattern_match")
    elif n == 255:
        injected = t_base(pattern_match=None)
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:pattern_match", "pattern_match", "unavailable")
    elif n == 254:
        injected = t_base(case_regression=None)
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:case_regression", "case_regression")
    elif n == 256:
        injected = t_base(case_regression=None)
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:case_regression", "case_regression", "unavailable")
    elif n == 257:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_false(location=passive_text("table"))
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:location", "location")
    elif n == 258:
        injected = t_base(detail=passive_text("field-absent:table"))
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:detail", "detail", "unavailable")
    elif n == 259:
        injected = t_false(source_version="BASE")
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-type", "unavailable")
    elif n == 260:
        injected = t_false(case_id="OTHER-CASE")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:case_id", "binding-mismatch")
    elif n == 261:
        injected = t_false(case_id="OTHER-CASE")
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-type", "unavailable")
    elif n == 262:
        injected = t_false(expected_value="synthetic-value")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "observation_unavailable", "outcome-index:0:call_index", "field-absent:subject-context")
    elif n == 263:
        injected = t_base(expected_value="synthetic-value")
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-type", "unavailable")
    elif n == 264:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_outer(extra_marker={"kind": "object"})
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:extra_marker", "unsupported-value")
    elif n == 265:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_outer(extra_marker={"kind": "object"})
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-type", "unavailable")
    elif n == 283:
        require_case(c, "RET-RECENT.done", "FIX-PRESERVATION-PREPARED")
        s["assertion"] = one_assertion(c, "ASSERT-RET-RECENT-DONE-PRESENT")
        s["obs"] = row_obs(constants, catalog)
        s["obs"]["call_index"] = "nope"
        expected = (record_0283(c),)
    elif n == 266:
        require_case(c, "RET-RECENT.done", "FIX-PRESERVATION-PREPARED")
        s["mode"] = "annotate_raw"
        expected = e_copy(record_0283(c))
    elif n == 267:
        negative = catalog["NEG-PAIR.cross-binding"]
        if negative["case_id"] != "NEG-PAIR.cross-binding" or negative["fixture_id"] != "FIX-BINDING-RULE":
            raise PreparationError("binding-context-identity")
        s["mode"] = "written"
        s["args"] = (
            {"case_id": "NEG-PAIR.cross-binding", "fixture_id": "FIX-BINDING-RULE", "source_version": "A1", "call_index": "nope"},
            {"case_id": "NEG-PAIR.cross-binding", "fixture_id": "FIX-BINDING-RULE", "source_version": "A1", "call_index": 1},
        )
        expected = (record_0267(),)
    elif n == 268:
        require_case(c, "NEG-PAIR.cross-binding", "FIX-BINDING-RULE")
        s["mode"] = "annotate_raw"
        expected = e_copy(record_0267())
    elif n == 269:
        require_case(c, "REP-SECOND.no-new-change", "FIX-PRESERVATION-PREPARED")
        injected = nonew_marker("rejected", "rejected-placeholder")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_copy(injected)
    elif n == 270:
        require_case(c, "REP-SECOND.no-new-change", "FIX-PRESERVATION-PREPARED")
        injected = nonew_marker("rejected", "rejected-placeholder")
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = call_env(constants, catalog)
        expected = regression(c, "A1", "observation_unavailable", "outcome:ASSERT-REP-NO-NEW-TASK-CHANGE", "field-absent:assertion-outcome", "unavailable")
    elif n == 271:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        if "table" not in one_assertion(c, "ASSERT-REP-CALL1-OLD-DONE-PRESENT"):
            raise PreparationError("intact-rep-table")
        injected = t_base()
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = class_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-type", "unavailable")
    elif n == 272:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_base()
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_copy(injected)
    elif n == 273:
        injected = t_false(source_version="BASE")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:call_index", "call-index-type")
    elif n == 274:
        injected = t_false(fixture_id="OTHER-FIXTURE")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:fixture_id", "binding-mismatch")
    elif n == 275:
        injected = t_false(assertion_id="ASSERT-NOT-IN-CASE")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:assertion_id", "binding-mismatch")
    elif n == 279:
        injected = recent_false()
        injected["case_id"] = "OTHER-CASE"
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:case_id", "binding-mismatch")
    elif n == 280:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_outer(expected_value="synthetic-value")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "observation_unavailable", "outcome-index:0:call_index", "field-absent:subject-context")
    elif n == 281:
        require_case(c, "REP-SECOND.no-new-change", "FIX-PRESERVATION-PREPARED")
        injected = nonew_marker(3, "out-of-point")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:call_index", "call-index-mismatch")
    elif n == 282:
        require_case(c, "REP-SECOND.no-new-change", "FIX-PRESERVATION-PREPARED")
        injected = nonew_marker(3, "out-of-point")
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = call_env(constants, catalog)
        expected = regression(c, "A1", "malformed_input", "outcome:call_index", "call-index-mismatch", "unavailable")
    elif n == 284:
        require_case(c, "NEG-PAIR.cross-binding", "FIX-BINDING-RULE")
        injected = record_0267()
        injected["case_id"] = "OTHER-CASE"
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:case_id", "binding-mismatch")
    elif n == 285:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_false(detail=passive_text("field-absent:table"))
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:detail", "detail")
    elif n == 286:
        require_case(c, "REP-SECOND.call-1", "FIX-PRESERVATION-PREPARED")
        injected = t_false(pattern_match=passive_text("not_applicable"))
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_val(injected, "malformed_input", "outcome-index:0:pattern_match", "pattern_match")
    elif n == 287:
        require_case(c, "REP-SECOND.no-new-change", "FIX-PRESERVATION-PREPARED")
        injected = nonew_marker("unavailable", "rejected-placeholder")
        s["mode"] = "annotate_injected"
        s["injected"] = (injected,)
        expected = e_copy(injected)
    elif n == 288:
        require_case(c, "REP-SECOND.no-new-change", "FIX-PRESERVATION-PREPARED")
        injected = nonew_marker("unavailable", "rejected-placeholder")
        s["mode"] = "classify_injected"
        s["injected"] = (injected,)
        s["obs"] = call_env(constants, catalog)
        expected = regression(c, "A1", "observation_unavailable", "outcome:ASSERT-REP-NO-NEW-TASK-CHANGE", "field-absent:assertion-outcome", "unavailable")
    else:
        raise PreparationError("unimplemented-vector")
    return finish_spec(s, expected, n)


def build_vector(row, catalog, constants, shared):
    n = vector_number(row["id"])
    if n <= 223:
        return build_inherited(row, catalog, constants, shared)
    if n <= 239:
        return build_block_b(row, catalog, constants, shared)
    return build_block_c(row, catalog, constants, shared)


def build_suite(catalog_module, rows):
    names = ("PRESERVATION_TASKS", "PRESERVATION_USERS", "SCHEMA_USERS_COLUMNS")
    constants = {name: copy.deepcopy(getattr(catalog_module, name)) for name in names}
    catalog = copy.deepcopy(catalog_module.CASES)
    if type(catalog) is not dict or len(catalog) != 39:
        raise PreparationError("catalog-case-count")
    assertions = [item["assertion_id"] for case in catalog.values() for item in case["assertions"]]
    if len(assertions) != 50 or len(set(assertions)) != 50:
        raise PreparationError("catalog-assertion-count")
    if len(catalog_module.CALL1_CONTROL_REQUIREMENTS) != 10 or len(catalog_module.CALL2_CONTROL_REQUIREMENTS) != 10:
        raise PreparationError("control-declaration-count")
    identity_ids = {
        row["assertion_id"] for row in rows
        if row["recipe"] == "catalog-identity" and row["source_version"] == "A1" and row["check_id"].startswith("CHK-A-")
    }
    if identity_ids != set(assertions):
        raise PreparationError("group-a-assertion-coverage")
    shared = {}
    suite = tuple(build_vector(row, catalog, constants, shared) for row in rows)
    if tuple(item["row"]["id"] for item in suite) != selection_ids():
        raise PreparationError("suite-order")
    return suite, collect_secrets(catalog)


def patterns_for(case, token):
    if type(case) is not dict:
        raise PreparationError("pattern-case")
    present = "base_regression_patterns" in case
    if token == "key-absent:literal-()":
        if present:
            raise PreparationError("pattern-key-present")
        return ()
    if token == "not-an-annotation-argument":
        raise PreparationError("pattern-not-annotation")
    suffix = token.split(":")[-1]
    if suffix != case.get("case_id"):
        raise PreparationError("pattern-case-binding")
    if not present or type(case["base_regression_patterns"]) is not tuple:
        raise PreparationError("pattern-missing")
    value = case["base_regression_patterns"]
    if token.startswith("key-present:exact-declared-empty-tuple:"):
        if len(value) != 0:
            raise PreparationError("pattern-not-empty")
        return value
    if token.startswith("key-present:exact-declared-tuple:"):
        return value
    raise PreparationError("pattern-token")


def compose_arguments(s, actual_returns):
    row = s["row"]
    if any(dep not in actual_returns for dep in row["dependencies"]):
        raise Blocked("producer-return-absent")
    c, a, obs = s["case"], s["assertion"], s["obs"]
    mode = s["mode"]
    if mode in ("utility", "written"):
        args = s["args"]
    elif mode == "dispatch":
        args = (c, obs)
    elif mode in ("annotate_raw", "annotate_injected"):
        material = actual_returns[row["dependencies"][0]] if mode == "annotate_raw" else s["injected"]
        args = (material, patterns_for(c, row["pattern_argument"]), c)
    elif mode in ("classify_raw", "classify_injected"):
        material = actual_returns[row["dependencies"][0]] if mode == "classify_raw" else s["injected"]
        args = (c, obs, material)
    elif mode == "classify_controls":
        controls = []
        if "fake_control" in s:
            controls.append(s["fake_control"])
        for producer_id in s["control_ids"]:
            value = actual_returns[producer_id]
            if type(value) not in (tuple, list) or len(value) != 1 or type(value[0]) is not dict:
                raise Blocked("control-return-shape")
            controls.append(value[0])
        obs["control_outcomes"] = tuple(controls)
        args = (c, obs, actual_returns["R13-V-0206"])
    elif row["entrypoint"] == "bindings_uniform":
        context = {
            "case_id": c["case_id"], "fixture_id": c["fixture_id"],
            "source_version": row["source_version"], "call_index": a["call_index"],
        }
        args = (context, obs)
    else:
        args = (c, obs, a)
    names = [part.strip() for part in row["argument_order"].split(",") if part.strip()]
    if len(args) != len(names):
        raise PreparationError("argument-arity")
    return args


def emit(event, **fields):
    payload = {"protocol": PROTOCOL, "event": event}
    payload.update(fields)
    sys.stdout.write(json.dumps(payload, ensure_ascii=True, separators=(",", ":"), allow_nan=False) + "\n")
    sys.stdout.flush()


def argument_integrity(args, argument_baseline, case, case_snapshot, producer_snapshots, actual_returns):
    """Post-call check of the assembled arguments plus the retained baselines.

    Returns preserved, mutated, or not-established. A snapshot failure is
    not-established. This function does not log the snapshots.
    """
    try:
        if not same_exact(graph_snapshot(args), argument_baseline):
            return "mutated"
        if case is not None and not same_exact(graph_snapshot(case), case_snapshot):
            return "mutated"
        for dep, snapshot in producer_snapshots.items():
            if not same_exact(graph_snapshot(actual_returns[dep]), snapshot):
                return "mutated"
    except Exception:
        return "not-established"
    return "preserved"


def run_suite(target, suite, secrets, attempt_id):
    """One invocation per selected rank. No retry, discovery, warm-up, or private call."""
    actual_returns = {}
    states = []
    stop_reason = None
    for s in suite:
        row = s["row"]
        xid = row["id"]
        if STOP_REQUESTED or stop_reason is not None:
            emit("not_run", id=xid, state="not-run", reason=stop_reason or "parent-stop-request", selection_rank=int(row["selection_rank"]))
            states.append({"id": xid, "state": "not-run", "started": False, "completed": False})
            continue
        try:
            # Setup-time shared-case baseline. A later per-call snapshot does not replace it.
            if s["case"] is not None and not same_exact(graph_snapshot(s["case"]), s["case_snapshot"]):
                raise PreparationError("shared-case-drift")
            args = compose_arguments(s, actual_returns)
            producer_snapshots = {dep: graph_snapshot(actual_returns[dep]) for dep in row["dependencies"]}
            secret_before = graph_snapshot(s["obs"]["tables"]["users"]["rows"][0]) if s.get("inspect_secrets") else None
        except Blocked as exc:
            emit("not_run", id=xid, state="blocked/not-run", reason=exc.args[0], selection_rank=int(row["selection_rank"]))
            states.append({"id": xid, "state": "blocked/not-run", "started": False, "completed": False})
            continue
        except Exception as exc:
            stop_reason = "input-preparation-failure"
            emit("boundary", id=xid, reason=stop_reason, error_type=type(exc).__name__)
            emit("not_run", id=xid, state="not-run", reason=stop_reason, selection_rank=int(row["selection_rank"]))
            states.append({"id": xid, "state": "not-run", "started": False, "completed": False})
            continue
        if STOP_REQUESTED:
            emit("not_run", id=xid, state="not-run", reason="parent-stop-request", selection_rank=int(row["selection_rank"]))
            states.append({"id": xid, "state": "not-run", "started": False, "completed": False})
            continue
        try:
            # After assembly, including control_outcomes. The original args object is the call input.
            argument_baseline = graph_snapshot(args)
        except Exception:
            stop_reason = "argument-integrity-not-established"
            emit("boundary", id=xid, reason=stop_reason)
            emit("not_run", id=xid, state="not-run", reason=stop_reason, selection_rank=int(row["selection_rank"]))
            states.append({"id": xid, "state": "not-run", "started": False, "completed": False})
            continue
        function = getattr(target, row["entrypoint"])
        emit("started", id=xid, entrypoint=row["entrypoint"], selection_rank=int(row["selection_rank"]))
        call_outcome = "return"
        value = None
        error_type = None
        try:
            value = function(*args)
        except Exception as exc:
            call_outcome = "exception"
            error_type = type(exc).__name__
        except BaseException as exc:
            call_outcome = "base"
            error_type = type(exc).__name__
        integrity = argument_integrity(
            args, argument_baseline, s["case"], s["case_snapshot"], producer_snapshots, actual_returns,
        )
        if call_outcome == "return":
            actual_returns[xid] = value
            matches = same_exact(value, s["expected"])
            fields = {"argument_integrity": integrity}
            if s.get("inspect_secrets"):
                try:
                    same_row = same_exact(graph_snapshot(s["obs"]["tables"]["users"]["rows"][0]), secret_before)
                    clean = not contains_secret(value, secrets)
                except Exception:
                    if integrity == "preserved":
                        integrity = "not-established"
                    fields["argument_integrity"] = integrity
                else:
                    fields["caller_row_unchanged"] = same_row
                    fields["returned_secret_values_absent"] = clean
                    matches = matches and same_row and clean
            expected_public = public_tree(s["expected"], secrets)
            fields["expected_evidence_sha256"] = hashlib.sha256(
                json.dumps(expected_public, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest()
            if not matches:
                fields["expected"] = expected_public
            emit(
                "completed", id=xid, check_id=row["check_id"], block=row["block"],
                category=row["category"], harness_match=matches, input_kind=s["input_kind"],
                consumed_producer_ids=list(row["dependencies"]),
                argument_provenance=row["argument_provenance"],
                selection_rank=int(row["selection_rank"]),
                actual=public_tree(value, secrets), **fields,
            )
            states.append({"id": xid, "state": "matched" if matches else "mismatched", "started": True, "completed": True})
        else:
            emit(
                "errored", id=xid, error_type=error_type, argument_integrity=integrity,
                selection_rank=int(row["selection_rank"]),
            )
            states.append({"id": xid, "state": "errored", "started": True, "completed": False})
            if call_outcome == "base":
                stop_reason = "target-base-exception"
                emit("boundary", id=xid, reason=stop_reason)
        if integrity != "preserved":
            reason = "argument-integrity-not-established" if integrity == "not-established" else "caller-argument-or-provenance-mutated"
            if stop_reason is None:
                stop_reason = reason
            emit("boundary", id=xid, reason=reason)
    totals = {
        "planned": PLANNED,
        "started": sum(item["started"] for item in states),
        "completed": sum(item["completed"] for item in states),
        "mismatched": sum(item["state"] == "mismatched" for item in states),
        "errored": sum(item["state"] == "errored" for item in states),
        "not_run": sum(not item["started"] for item in states),
        "blocked_not_run": sum(item["state"] == "blocked/not-run" for item in states),
    }
    emit(
        "finished", attempt_id=attempt_id, totals=totals,
        stop_reason=stop_reason or ("parent-stop-request" if STOP_REQUESTED else None),
        source_accepted=False, reviewer_acceptance=False, open_source_findings=["A2-C06"],
    )
    if stop_reason or STOP_REQUESTED:
        return 2
    if totals["mismatched"] or totals["errored"] or totals["not_run"]:
        return 1
    return 0


def load_whole_module(name, path, raw):
    """Future-only loader. Exact verified bytes. No extracted helpers or rewrites."""
    module = types.ModuleType(name)
    module.__file__ = path
    exec(compile(raw, path, "exec"), module.__dict__, module.__dict__)
    return module


def request_stop(_signal, _frame):
    global STOP_REQUESTED
    STOP_REQUESTED = True


def package_file(name):
    return os.path.dirname(__file__) + "/" + name


def main():
    parser = argparse.ArgumentParser(description="Review-only artifact. Future execution requires a separate authorization.")
    parser.add_argument("--authorization", required=True)
    parser.add_argument("--authorization-sha256", required=True)
    parser.add_argument("--parent-launch-id", required=True)
    options = parser.parse_args()
    if os.name != "posix" or sys.implementation.name != "cpython":
        raise PreparationError("posix-cpython-required")
    approval_bytes = read_regular(options.authorization, 131072)
    if hashlib.sha256(approval_bytes).hexdigest() != options.authorization_sha256:
        raise PreparationError("authorization-identity")
    approval = json.loads(approval_bytes)
    if approval.get("template_only") is True:
        raise PreparationError("template-only")
    if approval.get("implementation_review_accepted") is not True or approval.get("execution_authorized") is not True:
        raise PreparationError("execution-not-authorized")
    if type(approval.get("approval_reference")) is not str or not approval["approval_reference"].strip():
        raise PreparationError("approval-reference-required")
    if approval.get("attempt_id") != options.parent_launch_id or approval.get("interpreter_path") != sys.executable:
        raise PreparationError("launch-binding")
    self_raw = read_regular(__file__, 2097152)
    if identity(self_raw) != approval["reviewed_files"]["harness.py"]:
        raise PreparationError("harness-review-identity")
    source_bytes = {}
    source_identities = {}
    for role, (size, digest) in PINNED.items():
        path = approval["inputs"][role]
        raw = read_regular(path, size)
        if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
            raise PreparationError("pinned-input-mismatch")
        source_bytes[role] = raw
        source_identities[role] = {"path": path, **identity(raw)}
    if approval["inputs"]["ledger"] != package_file("A2_R13_VALIDATION_LEDGER.csv"):
        raise PreparationError("ledger-path-binding")
    projection_raw = read_regular(package_file("call_ledger.json"), 2097152)
    if identity(projection_raw) != approval["reviewed_files"]["call_ledger.json"]:
        raise PreparationError("projection-identity")
    projection = json.loads(projection_raw)
    rows = correspondence(source_bytes["ledger"].decode("utf-8"), projection)
    signal.signal(signal.SIGTERM, request_stop)
    catalog = load_whole_module("mizan_a2_r13_catalog", approval["inputs"]["catalog"], source_bytes["catalog"])
    target = load_whole_module("mizan_a2_r13_comparisons", approval["inputs"]["comparisons"], source_bytes["comparisons"])
    if not same_exact(target.__all__, PUBLIC_NAMES):
        raise PreparationError("public-interface-mismatch")
    if any(not callable(getattr(target, name, None)) for name in CALLED_NAMES):
        raise PreparationError("public-entry-not-callable")
    suite, secrets = build_suite(catalog, rows)
    expected_ledger = []
    for item in suite:
        tree = public_tree(item["expected"], secrets)
        expected_ledger.append({
            "id": item["row"]["id"],
            "sha256": hashlib.sha256(json.dumps(tree, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        })
    emit(
        "prepared", attempt_id=approval["attempt_id"],
        interpreter={"implementation": sys.implementation.name, "version": sys.version, "executable": sys.executable},
        inputs=source_identities, planned=PLANNED, check_groups=CHECK_GROUPS,
        expected_ledger=expected_ledger, guards_installed=False, guard_counts=None,
        prohibited_operation_coverage="not-instrumented", os_isolation_verified=False,
    )
    return run_suite(target, suite, secrets, approval["attempt_id"])


if __name__ == "__main__":
    try:
        code = main()
    except BaseException as error:
        try:
            emit("boundary", reason="harness-setup-or-reporting-failure", error_type=type(error).__name__)
        except BaseException:
            pass
        code = 2
    raise SystemExit(code)
