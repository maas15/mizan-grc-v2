"""MIZAN A2/R13 H4 POSIX parent. Written for review; not run in this batch.
Owns one direct child only. Does not import the R13 target modules or the harness.
Implements historical plan section 11 and the retained boundary corrections.
Does not claim verified containment, installed guards, or descendant cleanup.
Package identity is MIZAN_A2_R13_MEMORY_REVIEW_H4. Wire protocol
mizan-a2-r13-h1 stays the event protocol. It is not the historical R10
wire value and it is not acceptance. decode_protocol validates that wire
schema before attribution. The H2 runner and supervise algorithm stay.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import selectors
import shlex
import signal
import stat
import subprocess
import sys
import time

PROTOCOL = "mizan-a2-r13-h1"
WORKLOAD_SECONDS = 120.0
GRACE_SECONDS = 5.0
REAP_SECONDS = 2.0
DRAIN_SECONDS = 2.0
STREAM_LIMIT = 1048576
READ_CHUNK = 4096
PLANNED = 288
CHECK_GROUPS = 119
EXPECTED_ENTRY_COUNTS = {
    "compare_protected_rows": 56, "separate_base_regression_metadata": 59,
    "compare_rep_second": 39, "compare_scoped_columns": 36,
    "classify_case_regression": 36, "compare_supplied_case": 16,
    "compare_exact_field": 11, "compare_insert_shape": 10,
    "bindings_uniform": 10, "classify_commit_record": 5,
    "compare_schema_column": 4, "same_typed_value": 4,
    "missing_observation_fields": 2,
}
PINNED = {
    "plan": (78879, "dd241adb46d90eb0811c0d1dcc5bbc72f3067ef8ecd5baa30829904ef7399d19"),
    "catalog": (121298, "fe724e8001303617e08759abcafdc422626b39d8aed2a2564a0f39bec3ce94db"),
    "comparisons": (177397, "3d06fa6ad8605ba74a1395fa265af3ede14fe268f7c2bf061d25e21b0c35de65"),
    "map": (4033, "6b6b5f2c736543580d589ee670dd9b25e8452feebea4774d42d059cba75f72ab"),
    "addendum": (69181, "45d76de1b5722c67c2c37140d098d2ebccaa64d0da2da42049b2ea9e7107f8a5"),
    "ledger": (144197, "1eb5fc79bba34792cfe54da54e00028c520a7f92ff76861af1018d289c81ab81"),
}
REVIEWED = ("controller.py", "harness.py", "call_ledger.json", "A2_R13_VALIDATION_LEDGER.csv")
# Future-only bootstrap reads the SAME retained regular-file descriptor the
# parent measured, verifies the byte digest, then executes those exact bytes.
# No filesystem path is imported or discovered by the bootstrap.
BOOTSTRAP = r'''
import os, sys, hashlib
fd = int(sys.argv[1])
digest = sys.argv[2]
path = sys.argv[3]
with os.fdopen(fd, "rb") as source:
    raw = source.read(2097153)
if len(raw) > 2097152 or hashlib.sha256(raw).hexdigest() != digest:
    raise SystemExit(78)
argv = [path, "--authorization", sys.argv[4], "--authorization-sha256", sys.argv[5], "--parent-launch-id", sys.argv[6]]
sys.argv = argv
scope = {"__name__": "__main__", "__file__": path}
exec(compile(raw, path, "exec"), scope, scope)
'''


class Refused(Exception):
    """A review or execution prerequisite was not established."""


def components(path):
    if type(path) is not str or not path.startswith("/"):
        raise Refused("absolute-path-required")
    names = path.split("/")[1:]
    if not names or any(p in ("", ".", "..") for p in names):
        raise Refused("canonical-path-required")
    return names


def directory_fd(path):
    names = [] if path == "/" else components(path)
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in names:
            new = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = new
        return fd
    except BaseException:
        os.close(fd)
        raise


def open_regular(path):
    names = components(path)
    parent = directory_fd("/" + "/".join(names[:-1]) if len(names) > 1 else "/")
    try:
        fd = os.open(names[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            os.close(fd)
            raise Refused("regular-file-required")
        return fd
    finally:
        os.close(parent)


def read_fd(fd, limit):
    os.lseek(fd, 0, os.SEEK_SET)
    chunks = bytearray()
    while len(chunks) <= limit:
        part = os.read(fd, min(65536, limit + 1 - len(chunks)))
        if not part:
            break
        chunks.extend(part)
    if len(chunks) > limit:
        raise Refused("file-size-limit")
    os.lseek(fd, 0, os.SEEK_SET)
    return bytes(chunks)


def read_regular(path, limit):
    fd = open_regular(path)
    try:
        return read_fd(fd, limit)
    finally:
        os.close(fd)


def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def checked(path, spec, retain=False):
    if type(spec) is not dict or type(spec.get("bytes")) is not int or type(spec.get("sha256")) is not str:
        raise Refused("invalid-identity-spec")
    fd = open_regular(path)
    try:
        raw = read_fd(fd, spec["bytes"])
        if identity(raw) != spec:
            raise Refused("identity-mismatch")
        if retain:
            result = (raw, fd)
            fd = None
            return result
        return raw
    finally:
        if fd is not None:
            os.close(fd)


def create_evidence_directory(path):
    names = components(path)
    parent = directory_fd("/" + "/".join(names[:-1]) if len(names) > 1 else "/")
    try:
        os.mkdir(names[-1], mode=0o700, dir_fd=parent)  # Existing means refusal, even if empty.
        return os.open(names[-1], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
    finally:
        os.close(parent)


def write_new(fd, name, raw):
    if "/" in name or name in ("", ".", ".."):
        raise Refused("evidence-filename")
    out = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
    try:
        view = memoryview(raw)
        while view:
            n = os.write(out, view)
            if n <= 0:
                raise OSError("evidence-write-no-progress")
            view = view[n:]
        os.fsync(out)
    finally:
        os.close(out)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=True, indent=2, allow_nan=False) + "\n").encode("utf-8")


class Capture:
    """Retains a capped raw prefix. Discard counts include ONLY bytes actually read."""
    def __init__(self, name, fileobj):
        self.name = name
        self.fileobj = fileobj
        self.fd = fileobj.fileno()
        self.data = bytearray()
        self.discarded = 0
        self.overflow = False
        self.eof = False
        self.read_failure = False
        self.error_type = None
        self.closed_by_controller = False
        self.close_reason = None
        self.closed = False
        self.scan_offset = 0

    def close(self, selector, reason):
        if self.closed:
            return
        try:
            selector.unregister(self.fd)
        except (KeyError, ValueError):
            pass
        try:
            self.fileobj.close()
        except OSError as error:
            self.read_failure = True
            self.error_type = type(error).__name__
        self.closed = True
        self.closed_by_controller = True
        self.close_reason = reason

    def fields(self):
        return {
            "captured_bytes": len(self.data),
            "discarded_bytes_actually_read": self.discarded,
            "overflow": self.overflow, "eof": self.eof,
            "read_failure": self.read_failure, "read_error_type": self.error_type,
            "closed_by_controller": self.closed_by_controller, "close_reason": self.close_reason,
            "bytes_never_read": None,
            "full_stream": self.eof and not self.overflow and not self.read_failure,
            "sha256_of_captured_prefix": hashlib.sha256(self.data).hexdigest(),
        }


class Notifications:
    """Standalone-parent signal readiness. Does not discover or reap other PIDs."""
    def __init__(self):
        self.read_fd = self.write_fd = None
        self.old_wakeup = None
        self.old_handlers = {}
        self.requested_stop = None

    def handler(self, signum, _frame):
        if signum != signal.SIGCHLD:
            self.requested_stop = "parent-signal-" + str(signum)

    def install(self):
        self.read_fd, self.write_fd = os.pipe()
        os.set_blocking(self.read_fd, False)
        os.set_blocking(self.write_fd, False)
        try:
            for signum in (signal.SIGCHLD, signal.SIGINT, signal.SIGTERM):
                self.old_handlers[signum] = signal.getsignal(signum)
                signal.signal(signum, self.handler)
            self.old_wakeup = signal.set_wakeup_fd(self.write_fd, warn_on_full_buffer=False)
            if self.old_wakeup != -1:
                raise Refused("existing-signal-wakeup-owner")
        except BaseException:
            self.close()
            raise

    def close(self):
        if self.old_wakeup is not None:
            signal.set_wakeup_fd(self.old_wakeup)
            self.old_wakeup = None
        for signum, handler in self.old_handlers.items():
            signal.signal(signum, handler)
        self.old_handlers.clear()
        for name in ("read_fd", "write_fd"):
            fd = getattr(self, name)
            if fd is not None:
                os.close(fd)
                setattr(self, name, None)


def supervise(child, t0, notes, selector):
    """No wait(), communicate(), Popen context manager, or finalizer wait.

    Normal waits are readiness waits capped by the nearest active deadline.
    If the readiness primitive fails, stop immediately and use bounded
    nonblocking observation/read attempts (no fallback unbounded wait).
    """
    streams = {name: Capture(name, getattr(child, name)) for name in ("stdout", "stderr")}
    state = {
        "t0_monotonic": t0, "workload_deadline_monotonic": t0 + WORKLOAD_SECONDS,
        "stop_decision_monotonic": None, "grace_deadline_monotonic": None,
        "forceful_request_monotonic": None, "reap_deadline_monotonic": None,
        "exit_observed_monotonic": None, "drain_deadline_monotonic": None,
        "exit_observed": False, "reaped": False, "return_code": None,
        "reap_unverified": False, "timeout": False,
        "stop_reasons": [], "signal_requests": [], "poll_error_type": None,
        "readiness_failed": False, "drain_expired": False,
        "whole_invocation_ceiling_claimed": False,
        "descendant_cleanup_verified": False, "os_isolation_verified": False,
    }
    phase = "running"
    readiness_broken = False

    def observe_exit(now):
        """Nonblocking poll of the retained direct child.

        exit_observed_monotonic is the time of this observation. It is not
        the operating-system exit time and does not prove the child exited
        before the workload deadline. A polling exception is an observation
        failure: it does not set exit, and it does not clear an earlier exit.
        """
        try:
            code = child.poll()  # Nonblocking observation/reap on the retained handle.
        except Exception as error:
            state["poll_error_type"] = type(error).__name__
            return False
        if code is not None and not state["exit_observed"]:
            state["exit_observed"] = True
            state["reaped"] = True
            state["return_code"] = code
            state["exit_observed_monotonic"] = now
            if not all(s.eof for s in streams.values()):
                state["drain_deadline_monotonic"] = now + DRAIN_SECONDS
        return state["exit_observed"]

    def request(kind, now):
        if observe_exit(now):
            return
        result = {"kind": kind, "request_monotonic": now, "request_returned": False, "error_type": None}
        try:
            if kind == "terminate":
                child.terminate()
            else:
                child.kill()
            result["request_returned"] = True
        except Exception as error:
            result["error_type"] = type(error).__name__
        state["signal_requests"].append(result)
        # Successful request is not delivery, exit, or reap evidence.

    def commit_new_workload_timeout(now):
        """Commit workload-timeout only after a current observation.

        A Boolean sampled before observe_exit must not become the commit.
        An already committed timeout is not cleared, retimed, or cancelled
        by later exit or EOF. Other stop reasons are not suppressed here.
        """
        if state["timeout"] or "workload-timeout" in state["stop_reasons"]:
            return
        if phase != "running":
            return
        # Original T0 + 120 field. This comparison does not grant more time.
        if now < state["workload_deadline_monotonic"]:
            return
        observe_exit(now)
        if state["exit_observed"]:
            return
        state["timeout"] = True
        stop("workload-timeout", now)

    def stop(reason, now):
        nonlocal phase
        if reason not in state["stop_reasons"]:
            state["stop_reasons"].append(reason)
        if state["stop_decision_monotonic"] is not None:
            return
        state["stop_decision_monotonic"] = now
        if observe_exit(now):
            return
        phase = "grace"
        state["grace_deadline_monotonic"] = now + GRACE_SECONDS
        request("terminate", now)

    def inspect_stdout_prefix(stream, now):
        # Scan the already-retained prefix; no second persistent raw log buffer.
        while True:
            end = stream.data.find(b"\n", stream.scan_offset)
            if end < 0:
                # An unfinished record stays inside the retained prefix.
                # Length alone is not a stop. The 1048576-byte cap remains
                # the overflow rule. A final record without a newline is
                # still rejected later as a partial protocol line.
                return
            raw = bytes(stream.data[stream.scan_offset:end])
            stream.scan_offset = end + 1
            try:
                event = json.loads(raw)
                if type(event) is not dict or event.get("protocol") != PROTOCOL:
                    stop("unexpected-stdout", now)
                    continue
                if event.get("event") == "boundary":
                    stop("child-reported-boundary", now)
            except (ValueError, UnicodeError):
                stop("malformed-protocol", now)

    def read_once(stream, now):
        if stream.closed:
            return
        try:
            data = os.read(stream.fd, READ_CHUNK)
        except (BlockingIOError, InterruptedError):
            return
        except OSError as error:
            stream.read_failure = True
            stream.error_type = type(error).__name__
            stream.close(selector, "read-failure")
            stop("capture-failure-" + stream.name, now)
            return
        if data == b"":
            stream.eof = True
            stream.close(selector, "observed-eof")
            return
        room = STREAM_LIMIT - len(stream.data)
        retained = min(room, len(data))
        stream.data.extend(data[:retained])
        excess = len(data) - retained
        if excess:
            stream.discarded += excess
            stream.overflow = True
            stop("output-overflow-" + stream.name, now)
        if stream.name == "stdout" and not stream.overflow:
            inspect_stdout_prefix(stream, now)

    for stream in streams.values():
        try:
            os.set_blocking(stream.fd, False)
            selector.register(stream.fd, selectors.EVENT_READ, stream.name)
        except Exception as error:
            stream.read_failure = True
            stream.error_type = type(error).__name__
            stream.close(selector, "capture-setup-failure")
            stop("capture-setup-failure", time.monotonic())
    try:
        while True:
            now = time.monotonic()
            # No observation beyond the post-kill deadline is promoted to a
            # timely reap. This controller adds no late poll or finalizer wait.
            if not state["exit_observed"] and phase == "kill-observation" and now >= state["reap_deadline_monotonic"]:
                state["reap_unverified"] = True
                break
            observe_exit(now)
            # Commit while this cycle's phase is still the phase that entered
            # the cycle. A same-cycle stop must not hide a reached deadline,
            # and a failed poll is not treated as exit.
            commit_new_workload_timeout(now)
            if state["poll_error_type"] is not None:
                stop("child-observation-failure", now)
            if notes.requested_stop:
                stop(notes.requested_stop, now)
            if not state["exit_observed"] and phase == "grace" and now >= state["grace_deadline_monotonic"]:
                phase = "kill-observation"
                state["forceful_request_monotonic"] = now
                state["reap_deadline_monotonic"] = now + REAP_SECONDS
                request("kill", now)
            if not state["exit_observed"] and phase == "kill-observation" and now >= state["reap_deadline_monotonic"]:
                state["reap_unverified"] = True
                break
            if state["exit_observed"]:
                if all(s.eof for s in streams.values()):
                    break
                if state["drain_deadline_monotonic"] is None:
                    state["drain_deadline_monotonic"] = state["exit_observed_monotonic"] + DRAIN_SECONDS
                if now >= state["drain_deadline_monotonic"]:
                    state["drain_expired"] = True
                    break
                deadline = state["drain_deadline_monotonic"]
            elif phase == "running":
                deadline = t0 + WORKLOAD_SECONDS
            elif phase == "grace":
                deadline = state["grace_deadline_monotonic"]
            else:
                deadline = state["reap_deadline_monotonic"]
            if readiness_broken:
                # Readiness has already failed => attempt incomplete. These are
                # nonblocking bounded reads/polls, not sleeps or blocking waits.
                ready = [name for name, s in streams.items() if not s.closed]
            else:
                try:
                    ready = [key.data for key, _mask in selector.select(max(0.0, deadline - time.monotonic()))]
                except (OSError, ValueError) as error:
                    readiness_broken = True
                    state["readiness_failed"] = True
                    stop("readiness-failure", time.monotonic())
                    ready = [name for name, s in streams.items() if not s.closed]
            if time.monotonic() >= deadline:
                # Make the expired-deadline decision before servicing a late
                # readiness result; late EOF is not retroactive timely capture.
                continue
            if "signal" in ready:
                try:
                    os.read(notes.read_fd, READ_CHUNK)
                except (BlockingIOError, InterruptedError):
                    pass
                except OSError:
                    readiness_broken = True
                    state["readiness_failed"] = True
                    stop("signal-readiness-failure", time.monotonic())
            # One bounded read from EACH ready stream, never drain one first.
            for name in ("stdout", "stderr"):
                if name in ready and time.monotonic() < deadline:
                    read_once(streams[name], time.monotonic())
    except BaseException as error:
        # A parent-side supervision failure is not permission to abandon a
        # running child or add an unbounded finalizer wait. Keep the ORIGINAL
        # stop/kill/drain deadlines, and mark the whole attempt incomplete.
        state["supervision_exception_type"] = type(error).__name__
        now = time.monotonic()
        # Same commit rule, before this exception changes the phase.
        observe_exit(now)
        commit_new_workload_timeout(now)
        stop("supervision-exception", now)
        while True:
            now = time.monotonic()
            if not state["exit_observed"] and phase == "kill-observation" and now >= state["reap_deadline_monotonic"]:
                state["reap_unverified"] = True
                break
            observe_exit(now)
            commit_new_workload_timeout(now)
            if state["poll_error_type"] is not None:
                stop("child-observation-failure", now)
            if not state["exit_observed"] and phase == "grace" and now >= state["grace_deadline_monotonic"]:
                phase = "kill-observation"
                state["forceful_request_monotonic"] = now
                state["reap_deadline_monotonic"] = now + REAP_SECONDS
                request("kill", now)
            if state["exit_observed"]:
                if all(stream.eof for stream in streams.values()):
                    break
                if state["drain_deadline_monotonic"] is None:
                    state["drain_deadline_monotonic"] = state["exit_observed_monotonic"] + DRAIN_SECONDS
                deadline = state["drain_deadline_monotonic"]
                if now >= deadline:
                    state["drain_expired"] = True
                    break
            elif phase == "grace":
                deadline = state["grace_deadline_monotonic"]
            else:
                deadline = state["reap_deadline_monotonic"]
            for stream in streams.values():
                if not stream.closed and time.monotonic() < deadline:
                    try:
                        read_once(stream, time.monotonic())
                    except BaseException as read_error:
                        stream.read_failure = True
                        stream.error_type = type(read_error).__name__
                        stream.close(selector, "emergency-capture-failure")
            try:
                ready = selector.select(max(0.0, deadline - time.monotonic()))
                if any(key.data == "signal" for key, _mask in ready):
                    try:
                        os.read(notes.read_fd, READ_CHUNK)
                    except (BlockingIOError, InterruptedError):
                        pass
            except Exception:
                # Broken readiness: only nonblocking probes until the same
                # deadline, never a sleep/wait with an invented extra grace.
                state["readiness_failed"] = True
    finally:
        for stream in streams.values():
            if not stream.closed:
                reason = "reap-unverified" if state["reap_unverified"] else ("drain-deadline" if state["drain_expired"] else "supervision-finalize")
                stream.close(selector, reason)
        state["supervision_returned_monotonic"] = time.monotonic()
    state["streams"] = {name: stream.fields() for name, stream in streams.items()}
    state["boundary_complete"] = (
        state["exit_observed"] and state["reaped"] and not state["reap_unverified"]
        and not state["stop_reasons"] and not state["readiness_failed"]
        and all(s["full_stream"] for s in state["streams"].values())
    )
    return state, {name: s.data for name, s in streams.items()}


def decode_protocol(raw, ledger, approval, before):
    """Attribute captured events separately from complete ordered-protocol validation.

    Wire shape is checked before membership, nested access, or observation credit.
    A known vector keeps an explicit blocked or not-run event when its ledger
    rank is valid, even if an earlier event is missing. The gap stays a protocol
    issue. Missing events are not rewritten into starts, returns, or blocks.
    A malformed record does not become a vector result and does not erase a
    later attributable record.
    """
    ids = [r["vector_id"] for r in ledger]
    by_id = {r["vector_id"]: r for r in ledger}
    rank_of = {xid: index + 1 for index, xid in enumerate(ids)}
    result = {
        xid: {
            "id": xid, "observation_state": "start-unobserved", "started_observed": False,
            "completed_observed": False, "terminal_observed": False, "disposition": "unknown",
            "conflicts": [], "conflict_overflow": 0,
        }
        for xid in ids
    }
    issues = []
    prepared = finished = None
    pending = None
    frontier = 0
    schedule_gap = False
    expected_digests = {}
    boundaries = []
    unattributed = []
    input_kinds = {
        "synthetic-value", "injected-record", "producer-output",
        "mixed-producer-and-injected-control", "synthetic-observation",
    }
    total_keys = ("planned", "started", "completed", "mismatched", "errored", "not_run", "blocked_not_run")

    def mark_gap():
        nonlocal schedule_gap
        if not schedule_gap:
            schedule_gap = True
            issues.append("schedule-gap")

    def locate(line_offset):
        if len(unattributed) < 32:
            unattributed.append(line_offset)

    def remember_conflict(row, kind, rank, byte_offset):
        if len(row["conflicts"]) < 8:
            row["conflicts"].append({"kind": kind, "selection_rank": rank, "byte_offset": byte_offset})
        else:
            row["conflict_overflow"] += 1

    def sha256_text(value):
        if type(value) is not str or len(value) != 64:
            return False
        return all(ch in "0123456789abcdef" for ch in value)

    def note_integrity(event):
        integrity = event.get("argument_integrity")
        if integrity not in ("preserved", "mutated", "not-established"):
            issues.append("argument-integrity-absent")
            return False
        if integrity != "preserved":
            issues.append("argument-integrity")
        return True

    def prepared_binding(event):
        """Return the digest map only when the whole prepared record is valid.

        A failure returns None and does not invent missing fields. The caller
        decides whether a returned map may become the trusted setup.
        """
        required = {
            "protocol", "event", "attempt_id", "interpreter", "inputs", "planned",
            "check_groups", "expected_ledger", "guards_installed", "guard_counts",
            "prohibited_operation_coverage", "os_isolation_verified",
        }
        if set(event) != required:
            issues.append("prepared-field")
            return None
        if type(event.get("attempt_id")) is not str or event.get("attempt_id") != approval["attempt_id"]:
            issues.append("prepared-binding")
            return None
        if type(event.get("planned")) is not int or event.get("planned") != PLANNED or type(event.get("check_groups")) is not int or event.get("check_groups") != CHECK_GROUPS:
            issues.append("prepared-binding")
            return None
        interp = event.get("interpreter")
        if type(interp) is not dict or set(interp) != {"implementation", "version", "executable"}:
            issues.append("child-interpreter-binding")
            return None
        if type(interp.get("implementation")) is not str or type(interp.get("version")) is not str or type(interp.get("executable")) is not str:
            issues.append("child-interpreter-binding")
            return None
        if interp.get("implementation") != "cpython" or interp.get("executable") != approval["interpreter_path"]:
            issues.append("child-interpreter-binding")
            return None
        inputs = event.get("inputs")
        if type(inputs) is not dict or set(inputs) != set(PINNED):
            issues.append("child-input-binding")
            return None
        for role in PINNED:
            record = inputs.get(role)
            if type(record) is not dict or set(record) != {"path", "bytes", "sha256"}:
                issues.append("child-input-binding")
                return None
            if type(record.get("path")) is not str or type(record.get("bytes")) is not int or not sha256_text(record.get("sha256")):
                issues.append("child-input-binding")
                return None
            if record != before[role]:
                issues.append("child-input-binding")
                return None
        if event.get("guards_installed") is not False or event.get("guard_counts") is not None:
            issues.append("prepared-guard-binding")
            return None
        if event.get("prohibited_operation_coverage") != "not-instrumented" or event.get("os_isolation_verified") is not False:
            issues.append("prepared-guard-binding")
            return None
        entries = event.get("expected_ledger")
        if type(entries) is not list or len(entries) != PLANNED:
            issues.append("frozen-expectation-ledger")
            return None
        digests = {}
        seen = []
        for entry in entries:
            if type(entry) is not dict or set(entry) != {"id", "sha256"}:
                issues.append("frozen-expectation-ledger")
                return None
            eid = entry.get("id")
            digest = entry.get("sha256")
            if type(eid) is not str or not sha256_text(digest) or eid in digests:
                issues.append("frozen-expectation-ledger")
                return None
            digests[eid] = digest
            seen.append(eid)
        if seen != ids:
            issues.append("frozen-expectation-ledger")
            return None
        return digests

    def finished_shape(event):
        required = {
            "protocol", "event", "attempt_id", "totals", "stop_reason",
            "source_accepted", "reviewer_acceptance", "open_source_findings",
        }
        if set(event) != required:
            issues.append("finished-shape")
            return False
        if type(event.get("attempt_id")) is not str or event.get("attempt_id") != approval["attempt_id"]:
            issues.append("finished-attempt-binding")
            return False
        payload = event.get("totals")
        if type(payload) is not dict or set(payload) != set(total_keys) or any(type(payload[key]) is not int for key in total_keys):
            issues.append("finished-totals-type")
            return False
        if "stop_reason" not in event or not (event.get("stop_reason") is None or type(event.get("stop_reason")) is str):
            issues.append("finished-stop-reason")
            return False
        if event.get("source_accepted") is not False or event.get("reviewer_acceptance") is not False or event.get("open_source_findings") != ["A2-C06"]:
            issues.append("source-acceptance-drift")
            return False
        return True

    def completed_shape(event, xid):
        if "contract_acceptance_status" in event or "expected_from_R10_static_reading" in event:
            issues.append("historical-characterization-label")
            return False
        allowed = {
            "protocol", "event", "id", "check_id", "block", "category", "harness_match",
            "input_kind", "consumed_producer_ids", "argument_provenance", "selection_rank",
            "actual", "argument_integrity", "expected_evidence_sha256", "expected",
            "caller_row_unchanged", "returned_secret_values_absent",
        }
        if "actual" not in event:
            issues.append("completed-actual-absent")
            return False
        digest = event.get("expected_evidence_sha256")
        if "expected_evidence_sha256" not in event or not sha256_text(digest):
            issues.append("expectation-digest-absent")
            return False
        required = allowed - {"expected", "caller_row_unchanged", "returned_secret_values_absent"}
        if any(key not in allowed for key in event) or any(key not in event for key in required):
            issues.append("completed-field")
            return False
        match = event.get("harness_match")
        if type(match) is not bool:
            issues.append("match-type")
            return False
        if match is False and "expected" not in event:
            issues.append("expected-evidence-absent")
            return False
        row = by_id[xid]
        if type(event.get("check_id")) is not str or event.get("check_id") != row["check_group"]:
            issues.append("check-binding")
            return False
        if type(event.get("block")) is not str or event.get("block") != row["block"]:
            issues.append("block-binding")
            return False
        if type(event.get("category")) is not str or event.get("category") != row["category"]:
            issues.append("category-binding")
            return False
        if type(event.get("input_kind")) is not str or event.get("input_kind") not in input_kinds:
            issues.append("input-kind-binding")
            return False
        producers = event.get("consumed_producer_ids")
        if type(producers) is not list or any(type(item) is not str for item in producers) or producers != row["derived"]["dependencies"]:
            issues.append("consumed-producer-binding")
            return False
        if type(event.get("argument_provenance")) is not str or event.get("argument_provenance") != row["argument_provenance"]:
            issues.append("provenance-binding")
            return False
        if not note_integrity(event):
            return False
        if digest != expected_digests.get(xid):
            issues.append("expectation-digest-drift")
        left = "caller_row_unchanged" in event
        right = "returned_secret_values_absent" in event
        if left != right or (left and (type(event.get("caller_row_unchanged")) is not bool or type(event.get("returned_secret_values_absent")) is not bool)):
            issues.append("completed-secret-field")
            return False
        return True

    def errored_shape(event):
        error_type = event.get("error_type")
        if "error_type" not in event or type(error_type) is not str or error_type == "":
            issues.append("errored-type-absent")
            return False
        allowed = {"protocol", "event", "id", "error_type", "argument_integrity", "selection_rank"}
        if set(event) != allowed:
            issues.append("errored-field")
            return False
        return note_integrity(event)

    offset = 0
    for rawline in raw.splitlines(keepends=True):
        line_offset = offset
        offset += len(rawline)
        if not rawline.endswith(b"\n"):
            issues.append("partial-protocol-line")
            locate(line_offset)
            break
        try:
            event = json.loads(rawline)
        except (ValueError, UnicodeError):
            issues.append("invalid-protocol-json")
            locate(line_offset)
            continue
        if type(event) is not dict or type(event.get("protocol")) is not str or event.get("protocol") != PROTOCOL:
            issues.append("unexpected-protocol-record")
            locate(line_offset)
            continue
        kind = event.get("event")
        if type(kind) is not str:
            issues.append("event-kind-type")
            locate(line_offset)
            continue
        if finished is not None and kind != "finished":
            issues.append("records-after-finished")
        if kind == "boundary":
            allowed = {"protocol", "event", "reason", "id", "error_type"}
            if any(key not in allowed for key in event):
                issues.append("unexpected-event-field")
            reason = event.get("reason")
            if "reason" not in event or type(reason) is not str or reason == "":
                issues.append("boundary-reason")
            if "id" in event and type(event.get("id")) is not str:
                issues.append("boundary-id-type")
            elif "id" in event and event.get("id") not in by_id:
                issues.append("boundary-id")
            if "error_type" in event and (type(event.get("error_type")) is not str or event.get("error_type") == ""):
                issues.append("boundary-error-type")
            boundaries.append(event)
            continue
        if kind == "prepared":
            if prepared is not None or frontier or pending or schedule_gap:
                issues.append("prepared-order")
                prepared_binding(event)
                locate(line_offset)
                continue
            digests = prepared_binding(event)
            if digests is None:
                locate(line_offset)
                continue
            prepared = event
            expected_digests = digests
            continue
        if kind == "finished":
            if finished is not None:
                issues.append("duplicate-finished")
                locate(line_offset)
                continue
            if not finished_shape(event):
                locate(line_offset)
                continue
            finished = event
            if prepared is None or pending is not None or frontier != PLANNED or schedule_gap:
                issues.append("incomplete-vector-protocol")
            continue
        if prepared is None:
            issues.append("event-before-prepared")
            locate(line_offset)
            continue
        if "id" not in event:
            issues.append("vector-id-absent")
            locate(line_offset)
            continue
        xid = event.get("id")
        if type(xid) is not str:
            issues.append("vector-id-type")
            locate(line_offset)
            continue
        if xid not in by_id:
            issues.append("unknown-vector-id")
            locate(line_offset)
            continue
        rank = event.get("selection_rank")
        if "selection_rank" not in event or type(rank) is not int or rank != rank_of.get(xid):
            issues.append("selection-rank")
            locate(line_offset)
            continue
        row = result[xid]
        if kind == "started":
            allowed = {"protocol", "event", "id", "entrypoint", "selection_rank"}
            if set(event) != allowed or type(event.get("entrypoint")) is not str or event.get("entrypoint") != by_id[xid]["entrypoint"]:
                issues.append("entrypoint-binding")
                locate(line_offset)
                continue
            if boundaries:
                issues.append("start-after-boundary")
            if row["terminal_observed"]:
                issues.append("contradictory-terminal")
                remember_conflict(row, kind, rank, line_offset)
                mark_gap()
                continue
            if row["started_observed"]:
                issues.append("duplicate-start")
                remember_conflict(row, kind, rank, line_offset)
                mark_gap()
                continue
            row.update(started_observed=True)
            if row["disposition"] == "unknown":
                row["observation_state"] = "completion-unobserved"
            in_order = (not schedule_gap and pending is None and frontier < PLANNED and xid == ids[frontier])
            if in_order:
                pending = xid
            else:
                mark_gap()
                if pending is None:
                    pending = xid
                else:
                    issues.append("start-while-pending")
        elif kind in ("completed", "errored"):
            shape_ok = completed_shape(event, xid) if kind == "completed" else errored_shape(event)
            if not shape_ok:
                locate(line_offset)
                continue
            if row["terminal_observed"]:
                issues.append("contradictory-terminal")
                remember_conflict(row, kind, rank, line_offset)
                mark_gap()
                continue
            if not row["started_observed"]:
                issues.append("return-without-start")
            row["event"] = event
            row["terminal_observed"] = True
            if kind == "completed":
                row.update(observation_state="return-observed", completed_observed=True, disposition="completed")
            else:
                row.update(observation_state="error-observed", disposition="errored")
            in_order = (not schedule_gap and frontier < PLANNED and xid == ids[frontier] and (pending is None or pending == xid))
            if in_order:
                if pending == xid:
                    pending = None
                frontier += 1
            else:
                mark_gap()
        elif kind == "not_run":
            allowed = {"protocol", "event", "id", "state", "reason", "selection_rank"}
            state_name = event.get("state")
            reason = event.get("reason")
            if "reason" not in event or type(reason) is not str or reason == "":
                issues.append("not-run-reason")
                locate(line_offset)
                continue
            if state_name not in ("not-run", "blocked/not-run"):
                issues.append("not-run-state")
                locate(line_offset)
                continue
            if set(event) != allowed:
                issues.append("not-run-field")
                locate(line_offset)
                continue
            if row["terminal_observed"] or row["started_observed"]:
                issues.append("contradictory-terminal")
                remember_conflict(row, kind, rank, line_offset)
                mark_gap()
                continue
            if pending is not None and pending != xid:
                issues.append("not-run-while-other-pending")
            disposition = "blocked" if state_name == "blocked/not-run" else "not-run"
            row.update(observation_state=state_name, event=event, disposition=disposition, terminal_observed=True)
            in_order = (not schedule_gap and pending is None and frontier < PLANNED and xid == ids[frontier])
            if in_order:
                frontier += 1
            else:
                mark_gap()
        else:
            issues.append("unknown-protocol-event")
            locate(line_offset)
    totals = {
        "planned": PLANNED,
        "started": sum(r["started_observed"] for r in result.values()),
        "completed": sum(r["completed_observed"] for r in result.values()),
        "mismatched": sum(r.get("event", {}).get("event") == "completed" and r["event"].get("harness_match") is False for r in result.values()),
        "errored": sum(r["observation_state"] == "error-observed" for r in result.values()),
        "not_run": sum(r["observation_state"] in ("not-run", "blocked/not-run") for r in result.values()),
        "blocked_not_run": sum(r["observation_state"] == "blocked/not-run" for r in result.values()),
        "unknown": sum(r["disposition"] == "unknown" for r in result.values()),
        "conflicts": sum(len(r["conflicts"]) + r["conflict_overflow"] for r in result.values()),
    }
    if finished is None:
        issues.append("finished-not-observed")
    else:
        payload = finished.get("totals")
        counts_match = type(payload) is dict and set(payload) == set(total_keys) and all(type(payload[key]) is int and payload[key] == totals[key] for key in total_keys)
        if not counts_match:
            issues.append("totals-disagree")
    if finished is not None and (finished.get("source_accepted") is not False or finished.get("reviewer_acceptance") is not False or finished.get("open_source_findings") != ["A2-C06"]):
        issues.append("source-acceptance-drift")
    if prepared is None:
        issues.append("prepared-not-observed")
    for xid in ids:
        row = result[xid]
        row["start_observation"] = "start-observed" if row["started_observed"] else "start-unobserved"
        row["completion_observation"] = "completion-observed" if row["completed_observed"] or row["observation_state"] == "error-observed" else "completion-unobserved"
        # An explicit not-run/blocked disposition is that captured event only.
        # It does not create a start or a return, and a missing event stays unknown.
    unknown_starts = sum(r["start_observation"] == "start-unobserved" for r in result.values())
    unknown_completions = sum(r["completion_observation"] == "completion-unobserved" for r in result.values())
    stop_clear = finished is not None and "stop_reason" in finished and finished.get("stop_reason") is None
    return {
        "prepared": prepared, "finished": finished, "issues": issues,
        "boundaries": boundaries, "observed_totals": totals,
        "schedule_gap": schedule_gap, "contiguous_terminals": frontier,
        "unattributed_byte_offsets": unattributed,
        "start_unobserved_vectors": unknown_starts, "completion_unobserved_vectors": unknown_completions,
        "reported_totals": finished.get("totals") if finished else None,
        "protocol_complete": not issues and not boundaries and not schedule_gap and stop_clear,
    }, [result[xid] for xid in ids]


def selection_ids():
    ids = ["R13-V-" + str(i).zfill(4) for i in range(1, 266)]
    ids.append("R13-V-0283")
    ids.extend("R13-V-" + str(i).zfill(4) for i in range(266, 283))
    ids.extend("R13-V-" + str(i).zfill(4) for i in range(284, 289))
    return ids


def projection_acceptable(csv_raw, ledger):
    """Data check only. Duplicated from the harness rule and not an import of it."""
    import csv
    import io
    reader = csv.DictReader(io.StringIO(csv_raw.decode("utf-8")))
    csv_rows = list(reader)
    if len(csv_rows) != PLANNED or type(ledger) is not list or len(ledger) != PLANNED:
        raise Refused("ledger-count")
    by_id = {row["vector_id"]: row for row in csv_rows}
    if len(by_id) != PLANNED or [item.get("vector_id") for item in ledger] != selection_ids():
        raise Refused("selection-schedule")
    earlier = set()
    counts = {}
    groups = set()
    for index, item in enumerate(ledger):
        source = by_id[item["vector_id"]]
        for key, value in source.items():
            if item.get(key) != value:
                raise Refused("projection-cell")
        if int(source["selection_rank"]) != index + 1:
            raise Refused("selection-rank")
        deps = [part for part in source["dependency_ids"].split(";") if part]
        if list(item.get("derived", {}).get("dependencies", ())) != deps:
            raise Refused("derived-dependencies")
        for dep in deps:
            if dep not in earlier:
                raise Refused("nonpreceding-dependency")
        earlier.add(source["vector_id"])
        marker = " recipe "
        recipe = source["input_ref"].split(marker, 1)[1] if marker in source["input_ref"] else ""
        if item.get("derived", {}).get("recipe") != recipe:
            raise Refused("derived-recipe")
        counts[source["entrypoint"]] = counts.get(source["entrypoint"], 0) + 1
        groups.add(source["check_group"])
    if counts != EXPECTED_ENTRY_COUNTS or len(groups) != CHECK_GROUPS:
        raise Refused("check-ledger-identity")
    return counts


def preflight(options):
    if os.name != "posix" or sys.implementation.name != "cpython":
        raise Refused("posix-cpython-required")
    raw = read_regular(options.authorization, 131072)
    approval = json.loads(raw)
    if type(approval) is not dict:
        raise Refused("authorization-shape")
    if approval.get("template_only") is True:
        raise Refused("template-only")
    if approval.get("implementation_review_accepted") is not True or approval.get("execution_authorized") is not True:
        raise Refused("execution-not-authorized")
    if type(approval.get("approval_reference")) is not str or not approval["approval_reference"].strip():
        raise Refused("approval-reference-required")
    attempt_id = approval.get("attempt_id")
    if type(attempt_id) is not str or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", attempt_id):
        raise Refused("attempt-id-required")
    if approval.get("interpreter_path") != sys.executable:
        raise Refused("named-interpreter-mismatch")
    # The interpreter is named, not selected by PATH or an unverified version probe.
    interpreter_fd = open_regular(approval["interpreter_path"])
    os.close(interpreter_fd)
    for role, (_size, digest) in PINNED.items():
        if type(approval["inputs"][role]) is not str:
            raise Refused("input-path-required")
        pinned = approval.get("pinned_identities", {}).get(role)
        if type(pinned) is dict and pinned.get("sha256") != digest:
            raise Refused("pin-approval-binding")
    package = approval["package_directory"]
    pkg = directory_fd(package)
    os.close(pkg)
    if __file__ != package + "/controller.py":
        raise Refused("controller-path-binding")
    if approval["inputs"]["ledger"] != package + "/A2_R13_VALIDATION_LEDGER.csv":
        raise Refused("ledger-path-binding")
    before = {}
    paths = {}
    for role, (size, digest) in PINNED.items():
        path = approval["inputs"][role]
        value = checked(path, {"bytes": size, "sha256": digest})
        paths[role] = path
        before[role] = {"path": path, **identity(value)}
    harness_fd = None
    try:
        ledger_raw = None
        csv_raw = None
        for filename in REVIEWED:
            path = package + "/" + filename
            spec = approval["reviewed_files"][filename]
            if filename == "harness.py":
                value, harness_fd = checked(path, spec, retain=True)
            else:
                value = checked(path, spec)
            if filename == "call_ledger.json":
                ledger_raw = value
            if filename == "A2_R13_VALIDATION_LEDGER.csv":
                csv_raw = value
            paths[filename] = path
            before[filename] = {"path": path, **identity(value)}
        if identity(csv_raw) != {"bytes": PINNED["ledger"][0], "sha256": PINNED["ledger"][1]}:
            raise Refused("accepted-ledger-identity")
        if before["ledger"] != before["A2_R13_VALIDATION_LEDGER.csv"]:
            raise Refused("ledger-copy-mismatch")
        ledger = json.loads(ledger_raw)
        projection_acceptable(csv_raw, ledger)
        return approval, identity(raw), before, paths, ledger, ledger_raw, harness_fd
    except BaseException:
        if harness_fd is not None:
            os.close(harness_fd)
        raise


def main():
    parser = argparse.ArgumentParser(description="Future-only A2 R13 H4 controller. No launch without separate implementation acceptance and execution authorization.")
    parser.add_argument("--authorization", required=True)
    options = parser.parse_args()
    approval, approval_identity, before, paths, ledger, ledger_raw, harness_fd = preflight(options)
    evidence_fd = None
    notes = Notifications()
    selector = None
    child = None
    raw_streams = {"stdout": b"", "stderr": b""}
    state = None
    try:
        # Readiness prerequisites are established BEFORE creation, not within T0.
        notes.install()
        selector = selectors.DefaultSelector()
        selector.register(notes.read_fd, selectors.EVENT_READ, "signal")
        evidence_fd = create_evidence_directory(approval["evidence_directory"])
        command = [approval["interpreter_path"], "-I", "-B", "-S", "-u", "-c", BOOTSTRAP,
                   str(harness_fd), before["harness.py"]["sha256"], paths["harness.py"],
                   options.authorization, approval_identity["sha256"], approval["attempt_id"]]
        # No inherited application environment or secrets. No shell, PATH lookup,
        # repository discovery, site imports, automatic execution retry, or cwd scan.
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, bufsize=0, close_fds=True,
                                 pass_fds=(harness_fd,), env={}, cwd=approval["package_directory"])
        t0 = time.monotonic()  # Immediately after successful creation returns the handle.
        state, raw_streams = supervise(child, t0, notes, selector)
        os.close(harness_fd)
        harness_fd = None
        # No signal or wait is added after supervise returns, even if reap_unverified.
        after = {}
        post_identity_ok = state["exit_observed"]
        if state["exit_observed"]:
            for role, path in paths.items():
                try:
                    observed = read_regular(path, before[role]["bytes"])
                    after[role] = {"path": path, **identity(observed)}
                    if after[role] != before[role]:
                        post_identity_ok = False
                except Exception as error:
                    after[role] = {"path": path, "measurement_available": False, "error_type": type(error).__name__}
                    post_identity_ok = False
        else:
            after = None
        protocol, vectors = decode_protocol(raw_streams["stdout"], ledger, approval, before)
        totals = protocol["observed_totals"]
        unexpected_by_block = {"A": 0, "B": 0, "C": 0}
        for index, vector in enumerate(vectors):
            event = vector.get("event") or {}
            if event.get("event") == "completed" and event.get("harness_match") is False:
                unexpected_by_block[ledger[index]["block"]] += 1
        nonmatching = totals["mismatched"] or totals["errored"] or totals["not_run"]
        expected_exit = 1 if nonmatching else 0
        measurement_complete = (
            state["boundary_complete"] and protocol["protocol_complete"] and post_identity_ok
            and totals["started"] + totals["not_run"] == PLANNED
            and state["return_code"] == expected_exit
        )
        all_matching = measurement_complete and not nonmatching and totals["completed"] == PLANNED
        # An in-order schedule that includes mismatches, errors, or explicit
        # blocks can be a complete measurement with a nonzero result. A sticky
        # schedule gap, a boundary, or any other protocol issue keeps the
        # attempt incomplete even when a later attributable block was retained.
        # All-matching evidence is eligible for a separate reviewer decision.
        # It is not the historical known-characterization success label, and it
        # does not accept the source, close A2-C06, or accept this package.
        assessment_detail = None
        if not measurement_complete:
            decision = "execution incomplete"
        elif not all_matching:
            decision = "completed with unexpected comparator failures"
            assessment_detail = "nonzero mismatches, errors, or explicit blocks remain visible"
        else:
            decision = "eligible for separate reviewer decision"
        receipt = {
            "package": "MIZAN_A2_R13_MEMORY_REVIEW_H4", "attempt_id": approval["attempt_id"],
            "protocol": PROTOCOL,
            "authorization": {"path": options.authorization, **approval_identity, "reference": approval["approval_reference"]},
            "command_argv": command, "command_text": shlex.join(command),
            "parent_interpreter": {"implementation": sys.implementation.name, "version": sys.version, "executable": sys.executable},
            "child_environment": {}, "environment_allowlist": {},
            "inputs_and_package_before": before,
            "inputs_and_package_after_observed_exit": after, "post_identity_ok": post_identity_ok,
            "supervision": state, "protocol_evidence": protocol,
            "assessment": decision, "assessment_detail": assessment_detail,
            "measurement_complete": measurement_complete,
            "execution_complete": measurement_complete,
            "unexpected_by_block": unexpected_by_block,
            "eligible_for_reviewer_decision": all_matching,
            "reviewer_acceptance": False,
            "case_source_accepted": False,
            "a2_c06_closed_by_reviewer": False,
            "open_source_findings": ["A2-C06"],
            "historical_group_d_acceptance": "unaccepted",
            "h2_known_characterization_label_reused": False,
            "D3": "pending", "OP1E": "unaccepted", "S4": "open",
            "guards_installed": False, "guard_counts": None,
            "prohibited_operation_coverage": "not-instrumented",
            "os_isolation_verified": False,
            "descendant_cleanup_verified": False,
            "application_or_database_acceptance": False,
        }
        # All final evidence writes are OUTSIDE supervision/workload clocks.
        write_new(evidence_fd, "stdout.bin", raw_streams["stdout"])
        write_new(evidence_fd, "stderr.bin", raw_streams["stderr"])
        write_new(evidence_fd, "call_ledger.json", ledger_raw)
        write_new(evidence_fd, "vectors.json", json_bytes(vectors))
        write_new(evidence_fd, "receipt.json", json_bytes(receipt))
        print(json.dumps({"attempt_id": approval["attempt_id"], "assessment": decision, "assessment_detail": assessment_detail, "evidence_directory": approval["evidence_directory"], "source_accepted": False, "reviewer_acceptance": False}))
        # Eligibility is not source acceptance. Any non-match stays nonzero.
        # A nonzero status does not retry or repair the source.
        if not measurement_complete:
            return 2
        if not all_matching:
            return 1
        return 0
    finally:
        # Deliberately no child.wait/communicate/context-manager cleanup here.
        if harness_fd is not None:
            os.close(harness_fd)
        if evidence_fd is not None:
            os.close(evidence_fd)
        if selector is not None:
            selector.close()
        notes.close()


if __name__ == "__main__":
    try:
        status = main()
    except BaseException as error:
        print(json.dumps({"assessment": "controller did not finalize a complete attempt", "error_type": type(error).__name__, "source_accepted": False}))
        status = 2
    raise SystemExit(status)
