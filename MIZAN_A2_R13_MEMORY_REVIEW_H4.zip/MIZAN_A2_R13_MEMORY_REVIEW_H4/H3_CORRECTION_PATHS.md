# R13 H3 correction paths

These paths are source readings of `controller.py` and `harness.py` in `MIZAN_A2_R13_MEMORY_REVIEW_H3`. They were not executed. No fixture, mock, decoder probe, generated stream, target call, or receipt was created for them. Line numbers are this candidate's lines.

`decode_protocol` is `564–1010`. `main` calls it at `1175` and writes the five evidence files at `1234–1238` only after that call returns. `supervise` is `272–561` and was not changed. Its prefix scan at `365–385` still only stops on a non-dictionary, a wrong protocol string, a boundary event, or invalid JSON. A non-string vector ID on another event kind does not raise there.

## Valid complete stream as emitted by the unchanged harness

The harness runner functions are the H2 text. `emit` at `1782–1786` writes one JSON object and a newline. `main` emits `prepared` at `2003–2009` before `run_suite`. That record has `attempt_id`, the three string interpreter fields, six input records `{path, bytes, sha256}`, `planned` 288, `check_groups` 119, an `expected_ledger` of 288 `{id, sha256}` objects in suite order, and the four fixed guard fields.

`prepared_binding` at `629–700` accepts that shape only as a whole. Interpreter access at `649–657` happens after `type(interp) is dict` and an exact key set. Each ledger entry is checked at `686–696` before it is stored. The returned map is stored at `845–846` only when that function returns it. A valid harness `prepared` therefore becomes the trusted binding.

For each selected rank, `run_suite` emits `started` at `1851` with `id`, `entrypoint`, and integer `selection_rank`. The decoder requires that exact key set and the ledger entrypoint at `883–888`, then stores the first start at `901–906`. An in-order start sets `pending` at `904–906`.

A normal return emits `completed` at `1888–1895`. The payload includes string `id`, integer rank, `check_id` from the ledger group, block, category, Boolean `harness_match`, `input_kind`, the dependency list, `argument_provenance`, `argument_integrity`, a 64-character hex digest, and `actual` from `public_tree`. `expected` is added only when `matches` is false, at `1886–1887`. The two `0223` booleans are added only when that check completes, at `1879–1880`. `completed_shape` at `725–782` accepts that record: `actual` is present at `735`, the digest passes `sha256_text` at `738–739`, the conditional fields match the emitter, and the ledger bindings match. The first such terminal is stored at `925–935` and, when it is the in-order frontier ID, advances `frontier`.

An exceptional return emits `errored` at `1898–1901` with a non-empty `error_type` and `argument_integrity`. `errored_shape` at `784–793` accepts that exact key set. `not_run` at `1817`, `1828`, `1834`, `1838`, and `1847` carries `state` and a non-empty `reason`. The checks at `938–953` accept those two states. A vector `boundary` at `1833`, `1846`, `1905`, and `1910` has `reason` and, when present, string `id` and `error_type`. The global setup boundary at `2018` has `reason` and `error_type` and no `id`. The branch at `820–834` does not require a vector ID or a rank. `finished` at `1920–1924` has the seven integer totals, a present `stop_reason` that is null or a string, and the two false acceptance fields plus `["A2-C06"]`. `finished_shape` at `702–723` accepts that record. `type(...) is int` rejects a Boolean count.

After 288 in-order terminals, `frontier` is 288 and `pending` is empty. With no issues, no boundaries, `schedule_gap` false, and `stop_reason` null, `protocol_complete` at `1001–1009` is true. `measurement_complete` at `1184–1188` still requires the supervision boundary, post-exit identity, `started + not_run == 288`, and the child exit. `all_matching` at `1189` additionally requires no mismatch, error, or not-run total and `completed == 288`. Exit 0 at `1246` is that eligibility only. It is not source acceptance. This is the control flow of the unchanged emitter plus the new checks. It is not a captured stream.

## Valid preparation followed by `id=[]` or `id={}`

After a stored `prepared`, a vector event reaches `864`. The key `id` is present, so `vector-id-absent` does not fire. `xid = event.get("id")` at `868` is a list or a dictionary. `type(xid) is not str` at `869` appends `vector-id-type`, `locate` records the line offset when fewer than 32 offsets are stored, and `continue` runs before `xid not in by_id` at `873`. No dictionary membership is attempted, so this shape does not raise `TypeError`. The line is not written into any vector row. `terminal_observed` stays false. The issue remains in `issues`, so `protocol_complete` stays false.

## Missing, null, or numeric ID, and a Boolean or mismatched rank

A vector event with no `id` key hits `864–867` and appends `vector-id-absent`. JSON null and a JSON number are present and are not strings, so they take `vector-id-type` at `869–872`. There is no `str()` call on those values, and the decoder does not substitute `ids[frontier]`.

A Boolean rank fails `type(rank) is not int` at `878` because `type(True)` is `bool`. A missing rank fails the same test through `"selection_rank" not in event`. An integer that is not `rank_of[xid]` fails `rank != rank_of.get(xid)`. All three append `selection-rank` and continue before `result[xid]` is updated at `882`. The line is not assigned to another vector.

## Malformed ID, then the rank-267 block, with rank 266 absent

`selection_ids` at `1013–1018` is `0001` through `0265`, then `0283`, then `0266` through `0282`, then `0284` through `0288`. After in-order terminals through rank 265, `frontier` is 265 and `ids[265]` is `R13-V-0283`. `pending` is empty. The `0283` row is still the initial record from `577–584`: start unobserved, completion unobserved, disposition `unknown`. No event updates it. The decoder does not invent a start, a return, or a block for it.

A following line whose `id` is `[]` or `{}` takes `vector-id-type` as above. It is not attributed. It does not set `schedule_gap` by itself and does not move `frontier`.

The next line is a valid `not_run` for `R13-V-0266` at rank 267, with state `blocked/not-run` and a non-empty reason, matching the harness emit at `1828`. String ID, ledger membership, and exact integer rank pass `868–880`. The state and reason checks at `946–953` pass. The row update at `961–962` stores that event, sets disposition `blocked`, and sets `terminal_observed`. It does not set `started_observed` or `completed_observed`. `in_order` at `963` is false because `ids[265]` is `0283`, not `0266`. `mark_gap` at `967` appends `schedule-gap` once and leaves `frontier` at 265. `protocol_complete` is false because both the ID issue and the gap remain. `measurement_complete` and `all_matching` are therefore false. The assessment at `1198–1199` is `execution incomplete`, and the parent status at `1242–1243` is 2. The attempt is not eligible. `0283` stays unknown. The captured `0266` block stays on that row.

## Completed record missing only `actual`

`completed_shape` tests `"actual" not in event` at `735–737` before the other completed-field tests. The issue is `completed-actual-absent`. The function returns false. The caller at `914–917` does not store the event, does not set `terminal_observed` or `completed_observed`, and does not advance `frontier`. An earlier accepted start remains. The raw line stays in the retained stdout bytes. The issue token and, within the cap of 32, the byte offset are the structured locator. No actual value is invented.

Because the issue remains, `protocol_complete` is false. The rejected line is not in `completed`, so `totals["completed"] == 288` is false for a schedule that otherwise claimed 288 completions. `all_matching` at `1189` is false. Exit 0 is not reached. A later structurally valid terminal for the same ID can still be the first accepted terminal, because the malformed line did not occupy that slot. That later fact does not remove the earlier issue, so the attempt stays ineligible. This is not last-write-wins over the malformed claim.

## Actual present as null, false, zero, or empty

Presence is `"actual" not in event` at `735`. JSON null, false, zero, `""`, and an empty encoded collection are present keys. They do not take `completed-actual-absent`. The stored observation is `row["event"] = event` at `925`, which keeps the captured value. Nothing substitutes the expected tree. `harness_match` is still required to be an exact Boolean at `746–749`. A false match is a mismatch, not a missing field.

## Malformed, null, or list `prepared.interpreter`

`prepared_binding` checks `type(interp) is not dict` at `650` before any `.get` on that value. A list or null appends `child-interpreter-binding` and returns `None` at `651–652`. The partial digest map is never returned. The caller at `841–844` does not assign `prepared` or `expected_digests`. No trusted setup is fabricated. The same return happens when the three interpreter fields are not all strings, at `653–655`.

If this malformed record is the first `prepared` and no frontier, pending start, or schedule gap exists yet, a later record that passes `prepared_binding` completely may be stored at `845–846`. Events that arrived before that later binding already took `event-before-prepared` at `860–863` and are not replayed. The original `child-interpreter-binding` issue remains, so `protocol_complete` stays false. A `prepared` that arrives after a trusted binding, a frontier, a pending start, or a schedule gap takes `prepared-order` at `836–840`. `prepared_binding` may still record shape issues, and its return value is discarded. The existing binding is not overwritten.

## Expectation list with a bad element, a missing digest, or a wrong-typed digest

`entries` must be a list of length 288 at `680–683`. Each element must be a dictionary with exactly `{id, sha256}` at `687–689`. A non-dictionary element appends `frozen-expectation-ledger` and returns `None` immediately. It is not removed from the list, and the loop does not continue to index that element. A non-string ID, a digest that fails `sha256_text` at `615–618`, or a duplicate ID also returns `None` at `692–694`. `sha256_text` rejects a missing value because its type is not `str`. The function does not store `None` as a digest and does not build a shorter map of only the valid entries. `seen != ids` at `697–699` rejects a wrong order or a missing ID. Any of these failures leaves `prepared` unset.

## Missing completion digest while the setup digest is missing or invalid

A completion digest is tested at `738–741` before `digest != expected_digests.get(xid)` at `775`. A missing key, null, or any non-SHA-256 value appends `expectation-digest-absent` and returns false. The comparison is not reached, so a missing completion digest cannot succeed by equaling a missing setup digest.

An invalid setup digest never becomes `expected_digests`. `prepared_binding` returns `None` at `692–694`, and the caller does not store the binding. A later completion then hits `event-before-prepared` at `860–863`, which is before `completed_shape`. There is no `None == None` success on either path. A real digest that differs from a stored setup digest appends `expectation-digest-drift` at `775–776` and can still be stored. The issue keeps `protocol_complete` false. The parent does not rewrite `actual` to force a match.

## Errored record missing its required error type

`errored_shape` tests `error_type` at `785–788` before the key-set test. A missing key, a non-string, or `""` appends `errored-type-absent` and returns false. The caller does not store an error observation and does not invent an exception payload. The issue remains. `totals["errored"]` counts only rows whose `observation_state` is `error-observed`, at `976`, so this line is not an observed error.

## Return without a start, a start without a terminal, duplicates, and a second setup

A structurally valid terminal whose row has `started_observed` false appends `return-without-start` at `923–924` and still stores that terminal at `925–935`. `started_observed` stays false. When that ID is exactly `ids[frontier]`, `frontier` still advances. The issue remains, so the protocol stays incomplete. A start is not invented.

A stored start without an accepted terminal leaves disposition `unknown` and completion unobserved. `pending` stays set when the start was in order. A `finished` event while `pending` is set appends `incomplete-vector-protocol` at `857–858`.

A second accepted terminal, or a `not_run` after a start or terminal, appends `contradictory-terminal` and one conflict at `918–922` or `954–958`. A second start appends `duplicate-start` at `896–900`. The first stored fact remains. Conflicts stop at 8 records; further ones increment `conflict_overflow` at `609–613`. They are not a second call.

A second `prepared` after a trusted binding takes `prepared-order` at `836–840` and does not assign `expected_digests`. A duplicate `finished` appends `duplicate-finished` at `849–852` and does not replace the stored event.

## Missing provenance or malformed final totals

Missing `argument_provenance` fails `type(...) is not str` at `770–772` with `provenance-binding`. The ledger value is not copied into the event. Missing `consumed_producer_ids`, or a value that is not the ledger dependency list, is `consumed-producer-binding` at `766–769`. The return is not stored.

`finished.totals` must be a dictionary of the seven child keys, each `type is int`, at `713–716`. A Boolean fails that test with `finished-totals-type`, and the event is not stored. `True == 1` is not used. A missing `finished` appends `finished-not-observed` at `982–983`. A stored finished whose seven integers differ from the recomputed counts appends `totals-disagree` at `985–988`. The child totals are not copied over the rows. `stop_clear` at `1001` requires the key `stop_reason` to be present and null. A missing key is not treated as null. Any of these issues makes `protocol_complete` false, so measurement completeness and eligibility stay false.

## Evidence finalization after a structurally rejected event

The shapes above return from `decode_protocol` with `issues`, bounded `unattributed_byte_offsets`, the original rows, and any later accepted observations. They do not raise `TypeError`, `AttributeError`, or a missing-key error on the operations the review named. `main` then writes `stdout.bin`, `stderr.bin`, `call_ledger.json`, `vectors.json`, and `receipt.json` at `1234–1238` from the retained bytes and that returned structure. The receipt assessment is `execution incomplete` when `protocol_complete` is false. No child rerun and no synthetic replacement are in that path.

An evidence-write failure still leaves the attempt undelivered. The existing top-level handler at `1259–1264` remains for an unforeseen decoder fault. That handler prints the controller-failure summary and does not write the five files. No new handler returns an empty or successful protocol in its place. This reading does not claim that every operating-system write succeeds.
