# R13 H4 future evidence contract

This document describes records a future authorized attempt would write. This authoring round did not create an attempt directory, `stdout.bin`, `stderr.bin`, `vectors.json`, or `receipt.json`. No sample receipt is included.

## Attempt directory

The parent creates a new evidence directory and refuses to overwrite an existing one. After `supervise` returns, and outside the workload, grace, reap, and drain clocks, it writes:

| File | Content |
| --- | --- |
| `stdout.bin` | exact captured stdout bytes, up to the retention limit |
| `stderr.bin` | exact captured stderr bytes, up to the retention limit |
| `call_ledger.json` | the projection bytes the parent measured before the child started |
| `vectors.json` | per-vector interpretation, in `selection_rank` order |
| `receipt.json` | the receipt object below |

A failed evidence write does not become a complete delivery. The parent does not delete an incomplete attempt to hide it.

## Child events

Each event is one JSON object, one line, ending in a newline. The protocol string is `mizan-a2-r13-h1`. That string is the wire protocol, not the H4 package name. A partial line, invalid JSON, a non-object, or a different protocol string is an evidence failure. There is no 65536-byte protocol-line stop.

The parent checks this schema before using a field and before crediting an observation. A failed check appends a fixed issue token and, for at most 32 such lines, the byte offset in `unattributed_byte_offsets`. The offset is a locator into the retained stdout bytes. The issue token does not contain the payload. A rejected line is not a vector result. Later lines are still read. `protocol_complete` stays false while any issue, boundary, or schedule gap remains.

## Event schema

`protocol` is the exact string `mizan-a2-r13-h1` on every event. `event` is an exact string kind. JSON null, numbers, lists, and objects are not coerced into strings. Key presence is not truthiness: a present null, false, zero, or empty value is not a missing key. Boolean is not an integer.

| Kind | Required keys and types | Optional or conditional keys | Rejection |
| --- | --- | --- | --- |
| `prepared` | `attempt_id` string equal to the approval; `planned` integer 288; `check_groups` integer 119; `interpreter` object with string `implementation`, `version`, and `executable`; `inputs` object for the six pinned roles, each `{path, bytes, sha256}` with integer `bytes` and lowercase SHA-256 text; `expected_ledger` list of 288 objects `{id, sha256}` in rank order; `guards_installed` false; `guard_counts` null; `prohibited_operation_coverage` `not-instrumented`; `os_isolation_verified` false | none | The whole record is refused. No digest map is stored. A non-dictionary ledger entry is not skipped. A missing digest is not stored as null. A later prepared record does not replace a trusted binding |
| `started` | string `id` in the ledger; `selection_rank` exact integer equal to that ledger rank; `entrypoint` string equal to the ledger entrypoint | none | Not stored as a start. Wrong entrypoint is `entrypoint-binding` |
| `completed` | string `id` and exact integer `selection_rank` as on `started`; string `check_id` equal to ledger `check_group`; string `block` and `category` equal to the ledger; Boolean `harness_match`; exact string `input_kind` equal to one of the five emitted kinds; `consumed_producer_ids` the ledger dependency list; string `argument_provenance` equal to the ledger; `argument_integrity` one of `preserved`, `mutated`, `not-established`; lowercase SHA-256 `expected_evidence_sha256`; `actual` present. `entrypoint` is not a completed-event field | `expected` is required only when `harness_match` is false. `caller_row_unchanged` and `returned_secret_values_absent` are both absent or both Booleans | Missing `actual` is `completed-actual-absent` and is not return credit. A present falsey `actual` is kept. A missing or non-SHA-256 digest is `expectation-digest-absent` and is not compared as null. A real digest that differs from setup is `expectation-digest-drift`; the return can still be stored, and the issue keeps the attempt incomplete. An absent `input_kind`, `argument_provenance`, or `consumed_producer_ids` key is `completed-field` before any later check. A present non-string `input_kind` is `input-kind-binding` and is not used as a set member |
| `errored` | string `id` and exact integer `selection_rank`; non-empty string `error_type`; `argument_integrity` as on `completed`. `entrypoint` is not an errored-event field | none | Missing or non-string `error_type` is `errored-type-absent`. No exception text is invented. It is not an observed error |
| `not_run` | string `id` and exact integer `selection_rank`; `state` exactly `not-run` or `blocked/not-run`; non-empty string `reason`. `entrypoint` is not a not-run field | none | A bad reason is `not-run-reason`. A bad state is `not-run-state`. Neither becomes a block inferred from a missing producer |
| `boundary` | non-empty string `reason` | string `id` when the emitter has a vector; non-empty string `error_type` when the emitter has one. A setup boundary has neither | A non-string `id` is `boundary-id-type` and is not used as a key. The boundary is still retained, so the attempt is not clean. Rank is not required |
| `finished` | string `attempt_id`; `totals` object whose seven keys are integers, not Booleans; `stop_reason` present and either null or a string; `source_accepted` false; `reviewer_acceptance` false; `open_source_findings` exactly `["A2-C06"]` | none | A bad shape is not stored as `finished`. Reported totals are compared with recomputed counts only after the integer-type check. They are not copied over missing observations |

`input_kind` remains an exact string: `synthetic-value`, `injected-record`, `producer-output`, `mixed-producer-and-injected-control`, or `synthetic-observation`. Membership in that set is reached only after `type` is `str`. A list, object, null, number, or Boolean is not coerced and is not a valid return. An unknown exact string is the same `input-kind-binding` rejection.

Wire validity, attribution, schedule order, `harness_match`, and `argument_integrity` stay separate. A stored return with `harness_match` false is a mismatch, not a malformed wire record. A stored return with `argument_integrity` other than `preserved` remains a return and also an integrity issue.

Counting uses only accepted observations. A rejected terminal does not increment `completed`, `errored`, or `not_run`, and it does not remove an accepted start. The first accepted start or terminal stays. A later contradictory accepted record is a conflict, at most 8 records per vector, and is not a second call. `unknown` remains the disposition when no accepted terminal was stored. When every start was captured and one completion is rejected, `started + not_run` can still equal 288. The accepted completion count stays short of 288, and the sticky issue keeps `protocol_complete` false, so the attempt is not eligible. Exit 0 and reviewer eligibility require `protocol_complete` as well.

A malformed ID between rank 265 and a valid rank-267 block does not attribute that ID and does not stop the decoder. `R13-V-0283` stays unknown. The rank-267 block can still be stored. The issues and the schedule gap keep the attempt incomplete.

| Event | Meaning | What it does not prove |
| --- | --- | --- |
| `prepared` | The child checked the projection, loaded the two pinned R13 modules, built the suite, and froze one expectation digest per rank before the first target call | A comparison result, OS isolation, or reviewer acceptance |
| `started` | The child reached the recorded call site and wrote this event immediately before `getattr(target, entrypoint)(*args)` | Entry into the function body, or completion |
| `completed` | The child observed a return and compared it with the frozen expectation. The event also carries `argument_integrity` | That a target status of `failed` or `malformed_input` is a harness mismatch, or that a match proves the arguments were unchanged |
| `errored` | The started call raised. The event carries `error_type` and `argument_integrity` | A usable producer return, or that the exception proves the arguments were unchanged |
| `not_run` | The child states `not-run` or `blocked/not-run` for that rank | That missing output, by itself, means not-run |
| `boundary` | Setup, mutation, an unestablished integrity check, or stop handling prevented the schedule from continuing cleanly | That every prohibited operation was observed, or that the boundary replaces the terminal call event |
| `finished` | The child reports totals, `stop_reason`, `source_accepted=false`, `reviewer_acceptance=false`, and `open_source_findings=["A2-C06"]` | Process exit, EOF, or reaping |

`completed` carries `id`, `check_id`, `block`, `category`, `harness_match`, `argument_integrity`, `input_kind`, `consumed_producer_ids`, `argument_provenance`, `selection_rank`, `actual`, and `expected_evidence_sha256`. On a mismatch it also carries `expected`. Both trees are `public_tree` encodings. The oracle decision was already made on the original objects. `argument_integrity` is `preserved`, `mutated`, or `not-established`. It is not `harness_match`. `errored` carries `id`, `error_type`, `argument_integrity`, and `selection_rank`. It does not carry the exception payload.

`0223` still adds `caller_row_unchanged` and `returned_secret_values_absent` only when that dedicated check completes. Those booleans are combined into `harness_match` only in that case. If the dedicated check raises, the booleans are omitted and are not turned into a comparator mismatch.

A valid `input_kind` is the exact string `synthetic-value`, `injected-record`, `producer-output`, `mixed-producer-and-injected-control` for `0220`, or `synthetic-observation`. An injected call is not labeled `producer-output`.

`prepared.expected_ledger` lists `{id, sha256}` in rank order. The digest is the SHA-256 of the canonical JSON of the redacted expected tree. The parent compares each completed event's `expected_evidence_sha256` with that frozen digest.

## Observation, disposition, and usability

These stay separate.

| Field | Values |
| --- | --- |
| `start_observation` | `start-observed` only when the parent captured `started`; otherwise `start-unobserved` |
| `completion_observation` | `completion-observed` only when the parent captured `completed` or `errored`; otherwise `completion-unobserved` |
| `disposition` | `completed`, `errored`, `not-run`, `blocked`, or `unknown` |

A captured start without a captured return or error is `start-observed` and `completion-unobserved`, with disposition `unknown`. An explicit `not_run` event sets disposition to `blocked` or `not-run` from the child state and stores that event. It does not invent a start or a return. Start and completion for that vector stay unobserved. Absence of an event stays `unknown` and is not rewritten to `not-run` or `blocked`. A terminal without a captured start keeps `start-unobserved` and records `return-without-start`. The terminal fact is kept.

Attribution and schedule conformance are separate. A known ID whose `selection_rank` is an exact integer equal to the ledger rank is stored even when it is not the next in-order ID. The gap is the sticky issue `schedule-gap`. It is not removed by the later event. `vectors.json` is still emitted in ledger rank order. That presentation is not observed event order.

The first start and the first terminal are kept. A duplicate or a contradictory later record is appended to `conflicts`, at most 8 records, with `kind`, `selection_rank`, and `byte_offset`. Further conflicts increment `conflict_overflow`. One vector is not counted as two calls. An event that fails attribution is an issue and, for at most 32 such lines, a byte offset in `unattributed_byte_offsets`. It is not given to another vector.

`protocol_evidence` also carries `schedule_gap`, `contiguous_terminals`, and `unattributed_byte_offsets`. `observed_totals` adds `unknown` and `conflicts`. Those two keys are not part of the child's seven-key `finished.totals`. A mismatch on the seven shared keys is `totals-disagree`. The parent does not copy the child's totals over its own counts.

`protocol_complete` requires no issues, no boundaries, `schedule_gap` false, a `finished` event, and `stop_reason` null. A retained block or return does not satisfy that requirement while a gap, a conflict, or a missing required event remains. Measurement completeness, reviewer eligibility, and exit 0 follow `protocol_complete`. They are not implied by the presence of one captured fact.

Usability is not disposition and not target status. The child applies it while composing the next call:

- A completed one-element tuple or list of a dictionary can fill a control slot even when that dictionary's status is `failed`.
- A completed return of any other shape is unusable. The dependent emits `blocked/not-run` and no replacement value.
- A missing, errored, or not-run prerequisite is unusable. Its planned text is not substituted.
- The dependent block exists only as that dependent's own event. An unobserved producer does not, by itself, label the dependent blocked.

## Encoding and secrets

`public_tree` is evidence encoding, not the oracle.

| Value | Encoding |
| --- | --- |
| `None`, `bool`, `int` | themselves |
| `str` | the string, after replacing known secret substrings |
| `bytes` | `{"$bytes_hex": ...}`, or a redacted marker if a known secret is present |
| `float` | `{"$float": hex}` |
| `dict` | `{"$dict": [[key, value], ...]}` in existing key order |
| `tuple` / `list` | `{"$tuple": ...}` or `{"$list": ...}` |
| any other type, including a passive `str` subclass | `<unsupported:TypeName>` without calling `repr` |
| a field named `password_hash` or `reset_token` | `<redacted:field>` |
| a cycle or an over-budget value | a `$diagnostic` marker |

`0223` compares the caller row and the returned value with the in-memory secret set before redaction. The event records the two booleans `caller_row_unchanged` and `returned_secret_values_absent`. It does not print the secret values.

## Parent stream and process fields

| Field | Meaning |
| --- | --- |
| `captured_bytes` | bytes retained from that stream, at most 1048576 |
| `discarded_bytes_actually_read` | bytes the parent actually read after retention was full |
| `bytes_never_read` | null. The parent does not claim a count of bytes it never read |
| `overflow` | an additional byte was actually read after the retention limit |
| `eof` | a read ended with EOF. Closing the descriptor is not EOF |
| `read_failure` | a documented read or close failure |
| `closed_by_controller` / `close_reason` | the parent closed its read end, and why |
| `full_stream` | EOF, no overflow, and no read failure |
| `signal_requests` | termination or kill was requested. Not proof the signal was delivered or that the process exited |
| `exit_observed` / `return_code` | observation of the direct child |
| `reaped` / `reap_unverified` | reap was observed, or it could not be established inside the reap interval |
| `inputs_and_package_after_observed_exit` | remeasurement after observed exit. Null when exit was not observed |

The four intervals stay separate. They are not added into one invocation ceiling, extended because there are 288 calls, or reset per vector. There is no second supervisor.

## Receipt

`receipt.json` includes the package name, attempt id, protocol, authorization identity, the child argv, parent interpreter facts, `child_environment` `{}`, before-images, after-images, supervision state, protocol evidence, and:

| Field | Rule |
| --- | --- |
| `assessment` | `execution incomplete`, `completed with unexpected comparator failures`, or `eligible for separate reviewer decision` |
| `measurement_complete` | the boundary, `protocol_complete`, post-exit identity, `started + not_run == 288`, and the child exit agree. A schedule gap or an argument-integrity boundary keeps this false |
| `unexpected_by_block` | mismatch counts for A, B, and C |
| `eligible_for_reviewer_decision` | true only for a complete all-matching measurement |
| `reviewer_acceptance` | false |
| `case_source_accepted` | false |
| `a2_c06_closed_by_reviewer` | false |
| `application_or_database_acceptance` | false |
| `h2_known_characterization_label_reused` | false |
| `historical_group_d_acceptance` | `unaccepted` |
| `D3` / `OP1E` / `S4` | `pending` / `unaccepted` / `open` |
| `guards_installed` | false |
| `guard_counts` | null |
| `prohibited_operation_coverage` | `not-instrumented` |
| `os_isolation_verified` | false |
| `descendant_cleanup_verified` | false |
| `open_source_findings` | `["A2-C06"]` |

Eligibility is not source acceptance. A nonzero status does not authorize a retry or a source repair.
