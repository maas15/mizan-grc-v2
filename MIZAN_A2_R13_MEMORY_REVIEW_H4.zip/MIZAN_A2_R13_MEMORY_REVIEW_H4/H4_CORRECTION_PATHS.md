# R13 H4 correction paths

These paths are source readings of `controller.py` and `harness.py` in `MIZAN_A2_R13_MEMORY_REVIEW_H4`. They were not executed. No fixture, mock, decoder probe, generated stream, target call, or receipt was created for them. Line numbers are this candidate's lines. The one behavioral change is the exact-string test at `controller.py:763`. Later line numbers match H3 because that test replaced the membership test on the same line.

`H3_CORRECTION_PATHS.md` and `H3_FINDING_DISPOSITION.json` are byte-identical historical records. Two of their statements are qualified below. They are not the current conclusion.

## R13-H3-N001 qualifications

`H3` `EVIDENCE_CONTRACT.md` said that both `started + not_run == 288` and `completed == 288` are false after a rejected completion. The current rule is different. `totals` at `971–981` counts `started` from `started_observed` and `not_run` from accepted not-run states. A rejected completion does not clear `started_observed` and does not increment `not_run`. If all 288 starts were accepted and one completion is rejected, `started + not_run` can still equal 288. `completed` counts only `completed_observed`, so it is 287 in that reading. The issue remains, so `protocol_complete` at `1009` is false. `measurement_complete` at `1184–1188` requires `protocol_complete`, and `all_matching` at `1189` also requires `completed == 288`. Eligibility stays false. The code was not changed to force the start count short.

`H3_CORRECTION_PATHS.md`, under "Missing provenance or malformed final totals", said a missing `argument_provenance` reaches `provenance-binding` and a missing `consumed_producer_ids` reaches `consumed-producer-binding`. Both keys are in the required set at `742`. An absent key fails `any(key not in event for key in required)` at `743–745` and returns `completed-field` before `766–772`. A present value that is not a list of strings, or that differs from the ledger dependencies, can reach `consumed-producer-binding` at `766–769` when the earlier checks pass. A present non-string, or a string that differs from the ledger provenance, can reach `provenance-binding` at `770–772` on that same condition. The runtime order was not changed to match the old wording.

## Each allowed exact string

The harness still emits one of five strings at `1888–1895`: `synthetic-value`, `injected-record`, `producer-output`, `mixed-producer-and-injected-control`, or `synthetic-observation`. The set at `593–596` is those five strings. At `763`, `type(...) is str` is true, so membership is evaluated. A string in the set does not append `input-kind-binding`. The rest of `completed_shape` is unchanged. A fully valid completion is still stored at `925–928` and can advance the frontier when it is in order.

## Present list and present dictionary

After the required-key check at `742–745`, a present list or dictionary reaches `763`. `type(...) is not str` is true. The `or` stops before `not in input_kinds`, so the unhashable value is not used as a set member. The function appends `input-kind-binding` and returns false. The caller at `914–917` does not store the event, does not set `terminal_observed` or `completed_observed`, and calls `locate`. No actual or expected value is invented. `decode_protocol` continues with later lines and returns at `1002–1010`. This shape does not raise `TypeError`.

## Other present non-strings and an unknown exact string

JSON null, a number, and a Boolean are present keys, so they pass `completed-field`. They fail `type(...) is str` at `763` and take `input-kind-binding` without coercion. There is no `str()` call and no ledger substitute. An exact string that is not one of the five values passes the type test and fails membership. The issue token is the same `input-kind-binding`. The caller treats that false return like the list case: locator, no return credit, later lines still read.

## Missing `input_kind` key

`input_kind` is in `required` at `742`. A record that otherwise has the required keys, but lacks `input_kind`, fails at `743–745` with `completed-field` and returns before `763`. The type and membership test is not the first result for an absent key.

## Valid prior start, then a malformed completion

A valid `started` event is stored at `901–906`. `started_observed` becomes true and disposition stays `unknown` until an accepted terminal. A later completion whose `input_kind` is a list or dictionary returns false from `completed_shape`. The row is not updated at `925`. The start remains. Completion stays unobserved. The issue and, within the cap of 32, the byte offset remain. A later structurally valid terminal for that same ID can still be the first accepted terminal. The earlier issue keeps `protocol_complete` false.

## Gap at 0283, a malformed field, then the valid 0266 block

`selection_ids` at `1013–1018` places `R13-V-0283` at rank 266 and `R13-V-0266` at rank 267. After in-order terminals through rank 265, `frontier` is 265 and `ids[265]` is `R13-V-0283`. No event updates the `0283` row. It stays start unobserved, completion unobserved, and disposition `unknown`.

A completed line for another known ID, with a list or dictionary `input_kind` and otherwise valid framing, takes `input-kind-binding` as above. It is not a return. It does not by itself move `frontier`.

The following valid `not_run` for `R13-V-0266` at rank 267, with state `blocked/not-run` and a non-empty reason, passes `868–880` and `938–953`. The row update at `961–962` stores that block. It does not invent a start or a return. `in_order` at `963` is false because the frontier ID is still `0283`. `mark_gap` at `967` appends `schedule-gap` once. `protocol_complete` stays false. `0283` stays unknown. The captured `0266` block stays recorded. The attempt stays incomplete and is not eligible.

## Evidence finalization after the rejected field

The list and dictionary cases return from `decode_protocol` with the issue, the bounded locator, retained rows, and any later accepted observations. `main` calls the decoder at `1175` and writes `stdout.bin`, `stderr.bin`, `call_ledger.json`, `vectors.json`, and `receipt.json` at `1234–1238` only after that return. The assessment at `1198–1199` is `execution incomplete` while `protocol_complete` is false. No second child invocation and no synthetic receipt are in that path. An operating-system write can still fail. An unforeseen decoder fault still reaches the handler at `1259–1264`, which does not write the five files and does not invent a protocol.

## Missing versus present-invalid provenance keys

See the qualification above. Absence of `argument_provenance` or `consumed_producer_ids` is `completed-field` at `743–745`. A present invalid producer list is `consumed-producer-binding` at `766–769`. A present invalid provenance string is `provenance-binding` at `770–772`. Neither branch manufactures the ledger value. A false return does not credit the completion.
