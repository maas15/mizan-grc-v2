# Operator launch record — A2-H2-ATTEMPT-20261014-01

This file is an operator record. It is not one of the controller evidence files.

The controller was invoked once. It was not relaunched.

- Launcher: `env -i`
- Parent argv: `/usr/bin/python3.12` `/workspace/mizan-a2-r10-memory-review-h2/MIZAN_A2_R10_MEMORY_REVIEW_H2/controller.py` `--authorization` `/workspace/mizan-a2-r10-h2-execution-request/future-execution-authorization.json`
- Parent working directory: `/workspace`
- Parent environment: cleared by `env -i`. The process image exited before `/proc/<pid>/environ` was sampled.
- Start UTC: 2026-10-14T15:02:27.321048580Z
- End UTC: 2026-10-14T15:02:28.852609634Z
- Parent pid: 181934
- Parent exit status: 0
- Parent stdout: 246 bytes, fully retained in `parent-stdout.txt`
- Parent stderr: 0 bytes
- Direct child observed: pid 181936, started with `/usr/bin/python3.12 -I -B -S -u -c` and the controller bootstrap
- Execution-tool truncation or interruption: none observed

Controller evidence remains only in `/workspace/mizan-a2-h2-evidence-A2-H2-ATTEMPT-20261014-01`.
