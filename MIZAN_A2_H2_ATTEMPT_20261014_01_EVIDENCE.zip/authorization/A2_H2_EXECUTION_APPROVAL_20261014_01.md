# H2 single-attempt execution approval

Decision reference: `A2-H2-EXECUTION-APPROVAL-2026-10-14-01`

User decision recorded on October 14, 2026, for the attempt identified below. This is an external authorization record transcribing the user's explicit approval in the current conversation. It is not a digital signature, a run receipt, or proof of safety or completion.

## 1. Decision and authority

The user answered **yes** to executing `A2-H2-ATTEMPT-20261014-01` once under the reviewed execution request, with the `not-instrumented` observation limits accepted for this attempt only, and with no automatic repair, retry, or deployment.

Execution is now authorized within those precise limits. The earlier `execution_authorized=false` statements in the frozen request and package remain historical statements; do not edit them. The static-acceptance decision `A2-H2-STATIC-ACCEPTANCE-2026-10-14` remains separate and must not be substituted for this execution-approval reference.

This authoring round only read local files and archive members as bytes or text, parsed JSON as data, calculated hashes, and wrote these new authorization artifacts. It did not import or execute H2 or R10, invoke a comparator, run a test or syntax check, launch the proposed interpreter, or consume the authorized controller invocation. The current state of the remote Cursor workspace was not remeasured here.

## 2. Bound request and candidate

| Material | Bytes | SHA-256 |
| --- | ---: | --- |
| A2_H2_EXECUTION_REQUEST.md | 18602 | e5d7833481123c9441f8401d2b75c29df6520adae571939b1411841bf7fd9ca4 |
| MIZAN_A2_R10_MEMORY_REVIEW_H2.zip | 89930 | f13532e2eaeda82c476f548e2112a94be8ca8a7ddbca25e0b5502c9840586257 |
| A2_H2_STATIC_ACCEPTANCE_DECISION.md | 7932 | 25a80a368d59c695955e5de1eda64e3b743e037b9b690f9dd2ab5fa4d841e4e7 |
| controller.py | 38527 | bf9c43211232ed194b58f233590aff12b507f4840152c0071f2045928729f806 |
| harness.py | 131210 | f0c3a089f9320a0bb9983ee6ed3941eee23061c98325c6fe7e5e5ff3c7aea8f8 |
| call_ledger.json | 91780 | b0988f9f7106d3ed85aa4530b77873ffe1b94c171296543950f6ff8ab42af6f2 |

The request, archive, static-acceptance record, and three package members above were remeasured from the local attachments in this authoring round and matched these identities. The local V3 and R10 attachments also matched their existing pins and remain unchanged. These measurements do not certify current files at the remote workspace paths.

## 3. Attempt, interpreter, and paths

Attempt ID: `A2-H2-ATTEMPT-20261014-01`. Keep this exact identifier; do not generate a replacement if preparation or execution fails.

Candidate archive in the Cursor workspace:

`/workspace/mizan-a2-r10-memory-review-h2/MIZAN_A2_R10_MEMORY_REVIEW_H2.zip`

Package directory:

`/workspace/mizan-a2-r10-memory-review-h2/MIZAN_A2_R10_MEMORY_REVIEW_H2`

Separate operational authorization file:

`/workspace/mizan-a2-r10-h2-execution-request/future-execution-authorization.json`

Evidence directory, to be created exclusively by the unchanged controller:

`/workspace/mizan-a2-h2-evidence-A2-H2-ATTEMPT-20261014-01`

Interpreter: `/usr/bin/python3.12`.

The reviewed request reports this interpreter file as a regular, non-symlink file of 8020928 bytes, SHA-256 `e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f`. Recheck those file properties before launch. They do not prove runtime implementation, version, or executable identity. Those properties are checked or recorded through the accepted parent/child path during the authorized attempt, without a separate interpreter probe or substitution.

V3 and all R10 paths are fixed by the separate JSON and the reviewed request. No relocation into this chat's sandbox, unverified equivalent path, or replacement interpreter is authorized.

## 4. Operational JSON identity

File: `future-execution-authorization.json`

Bytes: 2740

SHA-256: `b4a38cfb2ab7b4b6eecc0de5137756560a5e63e01bc770047a49a841ccabb0f0`

This file is derived from the frozen H2 template as data, with the approved fields populated in a separate file. Preserve the original template and all package files unchanged. Install the exact JSON bytes outside the package with exclusive creation. Do not reserialize, edit, or silently replace the uploaded JSON. Verify its installed identity before launch.

The JSON's booleans are not proof of human approval by themselves and do not enforce single use cryptographically. Their authority is this recorded user decision. Cursor must prevent duplicate invocation operationally: stop if the authorization destination or evidence destination already exists, or if the attempt has already been launched or prior use cannot be determined. Do not delete evidence, alter the attempt ID, or recreate an authorization to circumvent that stop.

## 5. Authorized launch

The exact parent argument vector is:

```text
/usr/bin/python3.12
/workspace/mizan-a2-r10-memory-review-h2/MIZAN_A2_R10_MEMORY_REVIEW_H2/controller.py
--authorization
/workspace/mizan-a2-r10-h2-execution-request/future-execution-authorization.json
```

Launch that parent at most once, with an explicitly empty parent environment and without inheriting application configuration or secrets. The parent working directory is not a required input in the reviewed request. Do not alter the argument vector or add Python/CLI flags. Use the execution facility's environment controls or an environment-clearing launcher that preserves that vector. This is an operator launch constraint, not an added code guard or a claim of operating-system isolation.

Only the unchanged controller may create the measured direct child. Do not launch the harness separately, invoke public comparisons manually, or test bootstrap components separately. Runtime checks performed by the normal accepted code path are authorized within this invocation. Separate `--help`, `--version`, syntax checks, pytest runs, test collection, smoke tests, and timeout/process experiments remain unauthorized.

Reaching an invocation error, preflight refusal, syntax error, loading failure, timeout, incomplete output, mismatch, or an operator-tool interruption does not grant another launch. Preserve the actual observations and stop. Reattaching to an existing execution-tool session to retrieve its result is not a new launch; starting the command again is forbidden.

## 6. Workload, limits, and accepted observation scope

The workload remains V3's fixed 239 external call IDs in 107 check groups, on synthetic in-memory inputs only. Ordinary expectation mismatches may be collected while the approved boundary holds. A missing prerequisite must not be replaced by its written expected return. Boundary failure stops later selection. The planned count remains 239 even when fewer calls complete.

| Written interval or limit | Value |
| --- | --- |
| Workload budget | 120 seconds from T0 after successful direct-child creation |
| Termination grace | 5 seconds from the stop decision |
| Post-kill reap observation | 2 seconds from forceful-termination request |
| Post-exit EOF drain | 2 seconds from observed exit when EOF is missing |
| Raw-byte retention per stream | 1048576 bytes |
| Read quantum per ready stream per cycle | 4096 bytes |

Do not reset these intervals, add an outer timeout experiment, or represent their sum as a verified whole-invocation ceiling. Creation, pre-start reads, and final writes lie outside the workload timer as documented. Preserve the distinction between a signal request, observed exit, EOF, and reaping. Do not add process-name cleanup, a second supervisor, a detached rerun, or a descendant-cleanup claim.

The user accepts proceeding with the existing uninstalled-guard limitation for this attempt only:

```text
guard_counts = null
prohibited_operation_coverage = not-instrumented
```

This does not authorize prohibited operations, install guards, establish their absence, prove containment or prior-writer termination, or accept OP1E. No application imports, SQL (including an in-memory database), database access, network clients, child-created processes beyond the reviewed arrangement, source/expectation changes, dependency installation, H3, V4, R11, commit, merge, push, or deployment is authorized.

## 7. Evidence and mandatory stop

Use the controller's five evidence files if actually produced: `stdout.bin`, `stderr.bin`, `call_ledger.json`, `vectors.json`, and `receipt.json`. Preserve their original bytes. Do not create placeholders for missing files or edit receipt fields to improve the outcome.

Retain the parent invocation's actual output, return code, and launch/exit observations in separate operator records outside the controller evidence directory. Keep evidence generated by the operator distinguishable from evidence generated by H2. Report any execution-tool truncation, interruption, or unknown state; an absent event is not proof that a call never started. Do not expose credentials or secret payloads in the narrative summary.

Post-attempt review may read and hash evidence and frozen references as data without executing H2 again. Respect the controller's recorded exit state when interpreting after-images; do not imply a final state while exit remains unknown. Do not patch sources, the oracle, the authorization, or evidence during analysis.

Return the actual evidence and operational JSON, their identities, the parent and child statuses separately, completed and unknown counts, unexpected contract and Group D mismatches, capture/EOF/timeout/reap information, and the post-exit identity result. Stop after reporting, regardless of outcome. A clean attempt is not authorization for another run or release.

R10 source acceptance remains ungranted. A2-C06 remains open. Group D contract acceptance remains `unaccepted`. D3 remains pending. OP1E remains unaccepted. S4 remains open. No runtime result automatically changes these statuses.
